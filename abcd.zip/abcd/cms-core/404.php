<!DOCTYPE html>
<html>
<head>
    <title>Oops! Missing</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { background: var(--bg-light); display: flex; justify-content: center; align-items: center; height: 100vh; text-align: center; }
        .container { background: white; padding: 50px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); }
    </style>
</head>
<body>
    <div class="container">
        <div style="font-size: 100px;">🐾</div>
        <h1 style="color: var(--primary)">Huh? Page Not Found</h1>
        <p>Our little cub explorer can't find this spot.</p>
        <a href="/" class="btn">Go to Main Den</a>
    </div>
</body>
</html>
