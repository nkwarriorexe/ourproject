<?php
// Quick app smoke test
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();

echo "=== CMS Core Smoke Test ===\n\n";

// Test 1: Database
echo "1. Database Connection... ";
try {
    require_once 'config/db.php';
    $db = new Database();
    echo "✓ OK (driver: " . $db->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) . ")\n";
} catch (Exception $e) {
    echo "✗ FAIL: " . $e->getMessage() . "\n";
    exit(1);
}

// Test 2: Security
echo "2. Security class... ";
try {
    require_once 'core/Security.php';
    $token = Security::csrfToken();
    $safe = Security::safe("<script>alert('xss')</script>");
    echo "✓ OK (token: " . substr($token, 0, 8) . "..., safe: " . strlen($safe) . " chars)\n";
} catch (Exception $e) {
    echo "✗ FAIL: " . $e->getMessage() . "\n";
    exit(1);
}

// Test 3: Auth class
echo "3. Auth class... ";
try {
    require_once 'core/Auth.php';
    $auth = new Auth();
    echo "✓ OK (isLoggedIn: " . (Auth::isLoggedIn() ? 'true' : 'false') . ")\n";
} catch (Exception $e) {
    echo "✗ FAIL: " . $e->getMessage() . "\n";
    exit(1);
}

// Test 4: Users table
echo "4. Users table schema... ";
try {
    $tables = $db->pdo->query("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")->fetchAll();
    if (count($tables) > 0) {
        echo "✓ OK\n";
    } else {
        echo "✗ FAIL: Table missing\n";
        exit(1);
    }
} catch (Exception $e) {
    echo "✗ FAIL: " . $e->getMessage() . "\n";
    exit(1);
}

// Test 5: Create admin user
echo "5. Register admin user... ";
try {
    $hashed = password_hash('Admin@123', PASSWORD_DEFAULT);
    $db->pdo->prepare('DELETE FROM users WHERE email = ?')->execute(['admin@example.com']);
    $stmt = $db->pdo->prepare('INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)');
    $stmt->execute(['admin@example.com', $hashed, 'Admin User', 'admin']);
    echo "✓ OK\n";
} catch (Exception $e) {
    echo "✗ FAIL: " . $e->getMessage() . "\n";
}

// Test 6: Login attempt with admin
echo "6. Test admin login flow... ";
try {
    $auth = new Auth();
    if ($auth->login('admin@example.com', 'Admin@123')) {
        echo "✓ OK (user_id in session: " . $_SESSION['user_id'] . ")\n";
    } else {
        echo "✗ FAIL: Login returned false\n";
    }
} catch (Exception $e) {
    echo "✗ FAIL: " . $e->getMessage() . "\n";
}

echo "\n=== All Tests Passed ===\n";

$output = ob_get_clean();
echo $output;
?>
