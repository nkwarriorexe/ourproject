<?php
require_once __DIR__ . '/config/db.php';
$d = new Database();
echo 'driver: ' . $d->pdo->getAttribute(PDO::ATTR_DRIVER_NAME) . PHP_EOL;
$rows = $d->pdo->query('SELECT setting_key, setting_value FROM settings')->fetchAll();
echo 'settings: ' . count($rows) . PHP_EOL;
?>