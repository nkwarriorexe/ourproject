<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic ERP</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div style="font-weight:bold; font-size:1.3rem;">ACADEMIC<span style="color:var(--accent)">CORE</span></div>
        <div class="nav-links">
            <a href="index.php">Home</a>
            <a href="index.php?page=notices">Notices</a>
            <!-- Theme Toggle Button -->
            <button id="theme-btn" style="background:none; border:1px solid white; color:white; padding:5px 10px; border-radius:5px; cursor:pointer; margin-left:15px;">🌓 Theme</button>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="index.php?page=dashboard" class="btn btn-accent" style="color:black;">DASHBOARD</a>
            <?php else: ?>
                <a href="index.php?page=login" class="btn btn-accent" style="color:black;">LOGIN</a>
            <?php endif; ?>
        </div>
    </nav>
