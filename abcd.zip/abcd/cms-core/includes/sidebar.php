<?php
$role = $_SESSION['role'] ?? 'student';
$page = $_GET['page'] ?? 'dashboard';
?>
<aside class="sidebar">
    <div style="margin-bottom: 40px;">
        <h2 style="color: var(--accent); font-size: 1.2rem;">⚡ ACADEMIC CMS</h2>
        <small style="opacity: 0.5;">Institutional ERP</small>
    </div>

    <nav>
        <a href="index.php?page=dashboard" class="<?= $page=='dashboard'?'active':'' ?>">📊 Overview</a>
        <a href="index.php?page=notices" class="<?= $page=='notices'?'active':'' ?>">📢 Notice Board</a>

        <?php if ($role == 'admin'): ?>
            <div style="margin: 20px 0 10px 12px; font-size: 0.7rem; color: #64748b; text-transform: uppercase;">Admin Tools</div>
            <a href="index.php?page=users" class="<?= $page=='users'?'active':'' ?>">👥 Manage Users</a>
            <a href="index.php?page=applications" class="<?= $page=='applications'?'active':'' ?>">📄 Applications</a>
            <a href="index.php?page=results" class="<?= $page=='results'?'active':'' ?>">🏆 Manage Results</a>
        <?php endif; ?>

        <a href="index.php?page=logout" style="margin-top: 50px; color: #f87171;">🚪 Logout</a>
    </nav>
</aside>
