    <script src="assets/js/app.js"></script>
    <footer style="text-align:center; padding:20px; font-size:0.8rem; opacity:0.6;">
        &copy; 2024 Academic Core System.
    </footer>
</body>
</html>
