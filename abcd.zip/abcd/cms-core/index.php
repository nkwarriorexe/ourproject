<?php
session_start();
require_once 'config/db.php';
require_once 'core/Auth.php';

$page = $_GET['page'] ?? 'home';
$action = $_GET['action'] ?? ''; // Fixes the warning

$dashboard_pages = ['dashboard', 'applications', 'users', 'results'];

include 'includes/header.php';

if (in_array($page, $dashboard_pages)) {
    if (!Auth::isLoggedIn()) { header('Location: index.php?page=login'); exit; }
    
    echo '<div class="app-container">';
    include 'includes/sidebar.php';
    echo '<main class="main-content">';
    
    $file = "pages/$page.php";
    if (file_exists($file)) { include $file; } 
    else { echo "<h2>Module Under Construction</h2>"; }
    
    echo '</main></div>';
} else {
    $file = "pages/$page.php";
    if (file_exists($file)) { include $file; } 
    else { include 'pages/home.php'; }
}

include 'includes/footer.php';
?>
