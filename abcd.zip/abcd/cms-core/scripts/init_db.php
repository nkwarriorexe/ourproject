<?php
// scripts/init_db.php
// Usage: php init_db.php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';

try {
    $db = new Database();
    echo "Connected using driver: " . $db->driver . PHP_EOL;
    if ($db->driver === 'mongodb') {
        echo "MongoDB schema ensured." . PHP_EOL;
    } elseif ($db->pdo) {
        // attempt to import SQL file if present
        $sqlFile = __DIR__ . '/../database.sql';
        if (file_exists($sqlFile)) {
            echo "Importing SQL schema from database.sql..." . PHP_EOL;
            $sql = file_get_contents($sqlFile);
            // split statements by semicolon; naive but works for simple SQL
            $stmts = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($stmts as $stmt) {
                try {
                    $db->pdo->exec($stmt);
                } catch (PDOException $e) {
                    // ignore errors for statements like CREATE DATABASE when not allowed
                    error_log('SQL import statement error: ' . $e->getMessage());
                }
            }
            echo "SQL import attempted. Check logs for errors." . PHP_EOL;
        } else {
            echo "No database.sql found, ensure schema manually." . PHP_EOL;
        }
    }
} catch (Exception $e) {
    echo "Initialization failed: " . $e->getMessage() . PHP_EOL;
    exit(1);
}

echo "Done." . PHP_EOL;
