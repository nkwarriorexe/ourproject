<?php
require_once __DIR__ . '/../config/db.php';

class SessionManager {
    private $db;

    public function __construct() {
        $this->db = (new Database())->pdo;
    }

    /**
     * Create a new login session
     * @param int $userId
     * @param string $sessionId
     * @return bool
     */
    public function createSession($userId, $sessionId) {
        try {
            $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
            
            $stmt = $this->db->prepare("
                INSERT INTO login_sessions (user_id, session_id, ip_address, user_agent, login_time, last_activity, is_active)
                VALUES (:user_id, :session_id, :ip_address, :user_agent, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1)
            ");
            
            return $stmt->execute([
                ':user_id' => $userId,
                ':session_id' => $sessionId,
                ':ip_address' => $ipAddress,
                ':user_agent' => $userAgent
            ]);
        } catch (PDOException $e) {
            error_log("Create session error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Mark session as logout
     * @param string $sessionId
     * @return bool
     */
    public function logoutSession($sessionId) {
        try {
            $stmt = $this->db->prepare("
                UPDATE login_sessions 
                SET is_active = 0, logout_time = CURRENT_TIMESTAMP
                WHERE session_id = :session_id
            ");
            
            return $stmt->execute([':session_id' => $sessionId]);
        } catch (PDOException $e) {
            error_log("Logout session error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get all active sessions for a user
     * @param int $userId
     * @return array
     */
    public function getActiveSessions($userId) {
        try {
            $stmt = $this->db->prepare("
                SELECT id, ip_address, user_agent, login_time, last_activity
                FROM login_sessions
                WHERE user_id = :user_id AND is_active = 1
                ORDER BY last_activity DESC
            ");
            
            $stmt->execute([':user_id' => $userId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("Get active sessions error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get session history for a user
     * @param int $userId
     * @param int $limit
     * @return array
     */
    public function getSessionHistory($userId, $limit = 20) {
        try {
            $stmt = $this->db->prepare("
                SELECT id, ip_address, user_agent, login_time, logout_time, is_active
                FROM login_sessions
                WHERE user_id = :user_id
                ORDER BY login_time DESC
                LIMIT :limit
            ");
            
            $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            error_log("Get session history error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Logout from all devices
     * @param int $userId
     * @return bool
     */
    public function logoutAllSessions($userId) {
        try {
            $stmt = $this->db->prepare("
                UPDATE login_sessions 
                SET is_active = 0, logout_time = CURRENT_TIMESTAMP
                WHERE user_id = :user_id AND is_active = 1
            ");
            
            return $stmt->execute([':user_id' => $userId]);
        } catch (PDOException $e) {
            error_log("Logout all sessions error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get device name from user agent
     * @param string $userAgent
     * @return string
     */
    public static function getDeviceName($userAgent) {
        if (strpos($userAgent, 'Mobile') !== false) {
            return 'Mobile Device';
        } elseif (strpos($userAgent, 'iPad') !== false || strpos($userAgent, 'Tablet') !== false) {
            return 'Tablet';
        } else {
            return 'Desktop';
        }
    }

    /**
     * Get browser name from user agent
     * @param string $userAgent
     * @return string
     */
    public static function getBrowserName($userAgent) {
        if (strpos($userAgent, 'Chrome') !== false) return 'Chrome';
        if (strpos($userAgent, 'Safari') !== false) return 'Safari';
        if (strpos($userAgent, 'Firefox') !== false) return 'Firefox';
        if (strpos($userAgent, 'Edge') !== false) return 'Edge';
        if (strpos($userAgent, 'Opera') !== false) return 'Opera';
        return 'Unknown Browser';
    }

    /**
     * Update last activity time
     * @param string $sessionId
     * @return bool
     */
    public function updateLastActivity($sessionId) {
        try {
            $stmt = $this->db->prepare("
                UPDATE login_sessions 
                SET last_activity = CURRENT_TIMESTAMP
                WHERE session_id = :session_id
            ");
            
            return $stmt->execute([':session_id' => $sessionId]);
        } catch (PDOException $e) {
            error_log("Update last activity error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Logout from specific session
     * @param int $sessionId
     * @param int $userId (for verification)
     * @return bool
     */
    public function logoutFromDevice($sessionId, $userId) {
        try {
            $stmt = $this->db->prepare("
                UPDATE login_sessions 
                SET is_active = 0, logout_time = datetime('now')
                WHERE id = :id AND user_id = :user_id
            ");
            
            return $stmt->execute([
                ':id' => $sessionId,
                ':user_id' => $userId
            ]);
        } catch (PDOException $e) {
            error_log("Logout from device error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get active session count for a user
     * @param int $userId
     * @return int
     */
    public function getActiveSessionCount($userId) {
        try {
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count
                FROM login_sessions
                WHERE user_id = :user_id AND is_active = 1
            ");
            
            $stmt->execute([':user_id' => $userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            return $result['count'] ?? 0;
        } catch (PDOException $e) {
            error_log("Get session count error: " . $e->getMessage());
            return 0;
        }
    }
}
?>
