<?php
// core/System.php
require_once __DIR__ . '/../config/db.php';

class System {
    private $db;
    public $settings = [];

    public function __construct() {
        $this->db = (new Database())->pdo;
        $this->loadSettings();
    }

    private function loadSettings() {
        $stmt = $this->db->query("SELECT * FROM settings");
        while ($row = $stmt->fetch()) {
            $this->settings[$row['setting_key']] = $row['setting_value'];
        }
    }

    // Generates CSS Variables based on DB values
    public function getThemeCss() {
        return "
        :root {
            --primary: {$this->settings['primary_color']};
            --secondary: {$this->settings['secondary_color']};
            --text-light: {$this->settings['text_color_light']};
            --text-dark: {$this->settings['text_color_dark']};
            --glass: rgba(255, 255, 255, 0.1);
            --shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        }
        ";
    }
}
?>