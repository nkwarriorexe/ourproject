<?php
class Notices {
    private $db;
    public function __construct() { $this->db = (new Database())->pdo; }

    // Fixed: Put required parameter $createdBy first
    public function create($createdBy, $title, $content, $category = 'General', $priority = 'Normal', $targetAudience = 'All') {
        $stmt = $this->db->prepare("INSERT INTO notices (title, content, category, priority, target_audience, created_by) VALUES (?, ?, ?, ?, ?, ?)");
        return $stmt->execute([$title, $content, $category, $priority, $targetAudience, $createdBy]);
    }

    public function getAll($audience = 'All') {
        $stmt = $this->db->prepare("SELECT * FROM notices WHERE target_audience = ? OR target_audience = 'All' ORDER BY created_at DESC");
        $stmt->execute([$audience]);
        return $stmt->fetchAll();
    }
}
?>
