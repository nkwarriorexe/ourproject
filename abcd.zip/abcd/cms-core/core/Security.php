<?php
// core/Security.php
class Security {
    private static $key = "YOUR_32_BYTE_LONG_SECRET_KEY_!!!"; // Replace with a secure 32-byte key in production
    private static $cipher = "aes-256-cbc";

    public static function encrypt($data) {
        $ivlen = openssl_cipher_iv_length(self::$cipher);
        $iv = random_bytes($ivlen);
        $ciphertext_raw = openssl_encrypt($data, self::$cipher, self::$key, OPENSSL_RAW_DATA, $iv);
        return base64_encode($iv . $ciphertext_raw);
    }

    public static function decrypt($data) {
        $c = base64_decode($data);
        $ivlen = openssl_cipher_iv_length(self::$cipher);
        $iv = substr($c, 0, $ivlen);
        $ciphertext_raw = substr($c, $ivlen);
        return openssl_decrypt($ciphertext_raw, self::$cipher, self::$key, OPENSSL_RAW_DATA, $iv);
    }

    public static function safe($input) {
        return htmlspecialchars(strip_tags(trim((string)$input)), ENT_QUOTES, 'UTF-8');
    }

    // CSRF Token Management
    public static function csrfToken() {
        // Ensure session is active
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Only generate token if not already set
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        
        return $_SESSION['csrf_token'];
    }

    public static function checkCsrf($token) {
        // Ensure session is active
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // Check token is not empty and matches
        if (empty($token) || empty($_SESSION['csrf_token'])) {
            return false;
        }
        
        // Use constant-time string comparison
        return hash_equals($_SESSION['csrf_token'], $token);
    }
    
    /**
     * Regenerate CSRF token (called after login)
     */
    public static function regenerateCsrfToken() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        return $_SESSION['csrf_token'];
    }
}
