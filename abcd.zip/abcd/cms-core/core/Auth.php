<?php
require_once __DIR__ . '/../config/db.php';

class Auth {
    private $db;
    public function __construct() { $this->db = (new Database())->pdo; }

    public function login($email, $password) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['name'] = $user['name'];
            return true;
        }
        return false;
    }

    public static function isLoggedIn() { 
        if (session_status() === PHP_SESSION_NONE) session_start();
        return isset($_SESSION['user_id']); 
    }
}
?>
