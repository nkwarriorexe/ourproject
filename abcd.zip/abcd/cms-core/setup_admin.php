<?php
// setup_admin.php
// ⚠️ Run this ONCE, then DELETE this file immediately!

require_once 'config/db.php';

try {
    // 1. Connect to Database
    $database = new Database();
    $conn = $database->pdo;

    // 2. Define the Admin Credentials
    $admin_id = 'ADM001';
    $raw_password = 'adminn@123'; // Change this if you want a different default

    // 3. GENERATE SECURE HASH
    // PASSWORD_DEFAULT automatically uses the strongest algo available (Bcrypt or Argon2)
    // It handles the random salt generation securely for you.
    $secure_hash = password_hash($raw_password, PASSWORD_DEFAULT);

    // 4. Update the Database
    // We use a Prepared Statement to prevent SQL Injection
    $stmt = $conn->prepare("UPDATE users SET password_hash = :hash WHERE user_id = :uid");
    
    $stmt->execute([
        ':hash' => $secure_hash,
        ':uid'  => $admin_id
    ]);

    // 5. Success Message
    echo "<div style='font-family: sans-serif; text-align: center; margin-top: 50px;'>";
    if ($stmt->rowCount() > 0) {
        echo "<h1 style='color: green;'>✅ Admin Securely Configured</h1>";
        echo "<p>User ID: <strong>$admin_id</strong></p>";
        echo "<p>Password: <strong>$raw_password</strong></p>";
        echo "<p><em>Hash stored safely in DB.</em></p>";
        echo "<br><a href='index.php?page=login' style='background: #333; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Go to Login</a>";
    } else {
        echo "<h1 style='color: orange;'>⚠️ No Changes Made</h1>";
        echo "<p>The user 'ADM001' might not exist in the database yet, or the password was already set.</p>";
        echo "<p>Check if you ran the SQL to create the 'users' table first.</p>";
    }
    echo "</div>";

} catch (Exception $e) {
    echo "<h1>❌ Fatal Error</h1>";
    echo $e->getMessage();
}
?>