<?php
require_once 'config/db.php';
require_once 'core/Auth.php';
session_start();
if (!Auth::isLoggedIn()) { header('Location: login.php'); exit; }

$db = (new Database())->pdo;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST['settings'] as $key => $value) {
        $stmt = $db->prepare("UPDATE site_settings SET setting_value = ? WHERE setting_key = ?");
        $stmt->execute([$value, $key]);
    }
    $success = "Settings updated successfully!";
}

$settings = $db->query("SELECT setting_key, setting_value FROM site_settings")->fetchAll(PDO::FETCH_KEY_PAIR);
include 'includes/header.php';
?>
<div style="padding: 50px 10%;">
    <h2>⚙️ Public Website Settings</h2>
    <p style="color: var(--text-muted); margin-bottom: 30px;">Control what users see on the main homepage.</p>
    
    <?php if(isset($success)) echo "<p style='color:green; font-weight:bold;'>$success</p>"; ?>

    <form method="POST" style="background: var(--bg-card); padding: 40px; border-radius: 20px; border: 1px solid var(--border);">
        <div style="margin-bottom: 20px;">
            <label>College Name</label>
            <input type="text" name="settings[college_name]" value="<?php echo $settings['college_name']; ?>" style="width:100%; padding:10px; margin-top:5px; border-radius:8px; border:1px solid var(--border); background: var(--bg-main); color: var(--text-main);">
        </div>
        <div style="margin-bottom: 20px;">
            <label>Hero Title</label>
            <input type="text" name="settings[hero_title]" value="<?php echo $settings['hero_title']; ?>" style="width:100%; padding:10px; margin-top:5px; border-radius:8px; border:1px solid var(--border); background: var(--bg-main); color: var(--text-main);">
        </div>
        <div style="margin-bottom: 20px;">
            <label>Hero Subtitle</label>
            <textarea name="settings[hero_subtitle]" style="width:100%; padding:10px; margin-top:5px; border-radius:8px; border:1px solid var(--border); background: var(--bg-main); color: var(--text-main);"><?php echo $settings['hero_subtitle']; ?></textarea>
        </div>
        <button type="submit" class="btn">Save Configuration</button>
        <a href="dashboard.php" style="margin-left: 15px; color: var(--text-muted);">Back to Dashboard</a>
    </form>
</div>
