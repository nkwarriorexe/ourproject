<?php
require_once 'config/db.php';
$db = (new Database())->pdo;
$db->exec("TRUNCATE TABLE users");
$pass = password_hash('admin123', PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (email, password, name, role) VALUES (?, ?, 'Admin User', 'admin')");
$stmt->execute(['admin@test.com', $pass]);
echo "✅ Database Cleaned. Login: admin@test.com / Pass: admin123";
?>
