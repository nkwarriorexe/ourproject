document.addEventListener('DOMContentLoaded', () => {
    const themeBtn = document.getElementById('theme-btn');
    const html = document.documentElement;
    
    // Load saved theme
    const savedTheme = localStorage.getItem('theme') || 'light';
    html.setAttribute('data-theme', savedTheme);

    themeBtn.addEventListener('click', () => {
        const currentTheme = html.getAttribute('data-theme');
        let nextTheme = 'light';

        if (currentTheme === 'light') nextTheme = 'dark';
        else if (currentTheme === 'dark') nextTheme = 'orange';
        else nextTheme = 'light';

        html.setAttribute('data-theme', nextTheme);
        localStorage.setItem('theme', nextTheme);
    });
});
