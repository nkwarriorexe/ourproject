<?php
require_once 'config/db.php';
require_once 'core/Auth.php';
session_start();
if (Auth::isLoggedIn()) { header('Location: index.php?page=dashboard'); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $auth = new Auth();
    if ($auth->login($_POST['email'], $_POST['password'])) {
        header('Location: index.php?page=dashboard'); exit;
    } else { $error = "The credentials entered do not match our records."; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login | Academic Portal</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body style="display: flex; justify-content: center; align-items: center; height: 100vh; background: #E2E8F0;">
    <div class="glass-panel" style="width: 100%; max-width: 400px;">
        <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: var(--primary);">Login Portal</h1>
            <p style="font-size: 0.9rem; opacity: 0.7;">Access your academic resources</p>
        </div>
        <?php if(isset($error)) echo "<p style='color:red; margin-bottom:15px; text-align:center;'>$error</p>"; ?>
        <form method="POST">
            <label>Institutional Email</label>
            <input type="email" name="email" required style="width: 100%; padding: 12px; margin: 10px 0 20px 0; border: 1px solid #CBD5E1; border-radius: 8px;">
            <label>Secure Password</label>
            <input type="password" name="password" required style="width: 100%; padding: 12px; margin: 10px 0 20px 0; border: 1px solid #CBD5E1; border-radius: 8px;">
            <button type="submit" class="btn btn-primary" style="width: 100%;">Authorize Access</button>
        </form>
        <p style="text-align: center; margin-top: 20px;"><a href="/" style="color: var(--primary); text-decoration:none;">← Return to Main Website</a></p>
    </div>
</body>
</html>
