<?php require_once 'config/db.php'; include 'includes/header.php'; ?>
<div style="padding: 100px 5%; background: #E2E8F0;">
    <div class="glass-panel" style="max-width: 700px; margin: 0 auto;">
        <h2 style="color: var(--primary); margin-bottom: 20px;">Admission Application Form</h2>
        <form action="process_apply.php" method="POST">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div><label>Full Name</label><input type="text" name="name" required style="width:100%; padding:10px; margin-top:5px;"></div>
                <div><label>Email</label><input type="email" name="email" required style="width:100%; padding:10px; margin-top:5px;"></div>
                <div><label>Phone</label><input type="text" name="phone" required style="width:100%; padding:10px; margin-top:5px;"></div>
                <div><label>Desired Course</label>
                    <select name="course" style="width:100%; padding:10px; margin-top:5px;">
                        <option>Computer Science</option>
                        <option>Business Administration</option>
                        <option>Applied Physics</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 30px;">Submit Application</button>
        </form>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
