<?php require_once 'config/db.php'; include 'includes/header.php'; ?>
<div style="padding: 100px 5%; background: var(--bg-light); min-height: 80vh;">
    <div class="glass-panel" style="max-width: 600px; margin: 0 auto;">
        <h2 style="color: var(--primary); text-align: center; margin-bottom: 30px;">Academic GPA Calculator</h2>
        <div id="subjects">
            <div style="display: flex; gap: 10px; margin-bottom: 15px;">
                <input type="text" placeholder="Subject" style="flex: 2; padding: 10px; border-radius: 5px; border: 1px solid #ddd;">
                <input type="number" class="grade" placeholder="Grade (0.0 - 4.0)" step="0.1" style="flex: 1; padding: 10px; border-radius: 5px; border: 1px solid #ddd;">
            </div>
        </div>
        <button onclick="addSubject()" class="btn btn-primary" style="margin-bottom: 20px; font-size: 0.8rem;">+ Add Subject</button>
        <button onclick="calculateGPA()" class="btn btn-gold" style="width: 100%;">Calculate Final GPA</button>
        <div id="gpa-result" style="margin-top: 30px; text-align: center; font-size: 2rem; font-weight: 800; color: var(--primary);"></div>
    </div>
</div>
<script>
    function addSubject() {
        const div = document.createElement('div');
        div.style = "display: flex; gap: 10px; margin-bottom: 15px;";
        div.innerHTML = '<input type="text" placeholder="Subject" style="flex: 2; padding: 10px; border-radius: 5px; border: 1px solid #ddd;">' + 
                        '<input type="number" class="grade" placeholder="Grade" step="0.1" style="flex: 1; padding: 10px; border-radius: 5px; border: 1px solid #ddd;">';
        document.getElementById('subjects').appendChild(div);
    }
    function calculateGPA() {
        const grades = document.querySelectorAll('.grade');
        let total = 0;
        grades.forEach(g => total += parseFloat(g.value || 0));
        const final = total / grades.length;
        document.getElementById('gpa-result').innerHTML = "Your GPA: " + final.toFixed(2);
    }
</script>
<?php include 'includes/footer.php'; ?>
