<?php 
require_once 'config/db.php';
include 'includes/header.php'; 

$db = (new Database())->pdo;
$category = $_GET['cat'] ?? 'All';

if($category == 'All') {
    $stmt = $db->query("SELECT * FROM notices ORDER BY created_at DESC");
} else {
    $stmt = $db->prepare("SELECT * FROM notices WHERE category = ? ORDER BY created_at DESC");
    $stmt->execute([$category]);
}
$notices = $stmt->fetchAll();
?>

<main style="padding: 40px 5%;">
    <div style="text-align: center; margin-bottom: 50px;">
        <h1 style="font-size: 2.5rem;">Campus <span style="color: var(--primary)">Notice Board</span></h1>
        <p style="color: var(--text-muted)">Stay updated with the latest happenings on campus.</p>
    </div>

    <!-- Category Filter -->
    <div style="display: flex; gap: 10px; justify-content: center; margin-bottom: 40px; flex-wrap: wrap;">
        <a href="?cat=All" class="btn" style="background: <?php echo $category=='All' ? 'var(--primary)' : 'var(--bg-card)'; ?>; color: <?php echo $category=='All' ? '#fff' : 'var(--text-main)'; ?>;">All</a>
        <a href="?cat=Academic" class="btn" style="background: <?php echo $category=='Academic' ? 'var(--primary)' : 'var(--bg-card)'; ?>; color: <?php echo $category=='Academic' ? '#fff' : 'var(--text-main)'; ?>;">Academic</a>
        <a href="?cat=Events" class="btn" style="background: <?php echo $category=='Events' ? 'var(--primary)' : 'var(--bg-card)'; ?>; color: <?php echo $category=='Events' ? '#fff' : 'var(--text-main)'; ?>;">Events</a>
        <a href="?cat=Admin" class="btn" style="background: <?php echo $category=='Admin' ? 'var(--primary)' : 'var(--bg-card)'; ?>; color: <?php echo $category=='Admin' ? '#fff' : 'var(--text-main)'; ?>;">Admin</a>
    </div>

    <div style="max-width: 900px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px;">
        <?php foreach($notices as $n): ?>
        <div style="background: var(--bg-card); padding: 25px; border-radius: 20px; border: 1px solid var(--border); box-shadow: 0 5px 15px rgba(0,0,0,0.05);">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                <span style="background: var(--border); color: var(--primary); padding: 4px 10px; border-radius: 8px; font-size: 0.7rem; font-weight: bold;"><?php echo $n['category']; ?></span>
                <span style="color: var(--text-muted); font-size: 0.8rem;"><?php echo date('F d, Y', strtotime($n['created_at'])); ?></span>
            </div>
            <h3 style="margin-bottom: 10px;"><?php echo $n['title']; ?></h3>
            <p style="color: var(--text-muted); line-height: 1.8;"><?php echo nl2br($n['content']); ?></p>
        </div>
        <?php endforeach; ?>

        <?php if(empty($notices)): ?>
            <div style="text-align: center; padding: 50px;">
                <p style="color: var(--text-muted)">No notices found in this category.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>
