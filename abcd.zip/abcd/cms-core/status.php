<?php
// Quick test page to verify DB and app status
require_once 'config/db.php';
require_once 'core/Auth.php';
require_once 'core/System.php';
require_once 'core/Notices.php';

$status = [
    'database' => 'Unknown',
    'users' => 0,
    'notices' => 0,
    'settings' => 0,
    'errors' => []
];

try {
    $db = new Database();
    if ($db->pdo) {
        $status['database'] = '✅ Connected';
        
        // Count users
        $result = $db->pdo->query("SELECT COUNT(*) as count FROM users")->fetch(PDO::FETCH_ASSOC);
        $status['users'] = $result['count'] ?? 0;
        
        // Count notices
        $result = $db->pdo->query("SELECT COUNT(*) as count FROM notices")->fetch(PDO::FETCH_ASSOC);
        $status['notices'] = $result['count'] ?? 0;
        
        // Count settings
        $result = $db->pdo->query("SELECT COUNT(*) as count FROM settings")->fetch(PDO::FETCH_ASSOC);
        $status['settings'] = $result['count'] ?? 0;
    }
} catch (Exception $e) {
    $status['database'] = '❌ Failed';
    $status['errors'][] = $e->getMessage();
}

header('Content-Type: application/json');
echo json_encode($status, JSON_PRETTY_PRINT);
