<?php
// config/db.php - database connector with MySQL (preferred) and SQLite fallback
require_once __DIR__ . '/config.php';

use MongoDB\Client as MongoClient;

class Database {
    private $host;
    private $db_name;
    private $username;
    private $password;
    public $pdo;
    public $mongo;
    public $driver;

    public function __construct() {
        $this->host = defined('DB_HOST') ? DB_HOST : '127.0.0.1';
        $this->db_name = defined('DB_NAME') ? DB_NAME : 'cms';
        $this->username = defined('DB_USER') ? DB_USER : 'root';
        $this->password = defined('DB_PASS') ? DB_PASS : '';
        $this->driver = defined('DB_DRIVER') ? DB_DRIVER : 'mysql';

        $this->pdo = null;
        $this->mongo = null;

        if ($this->driver === 'mongodb') {
            $this->connectMongo();
        } else {
            // try to connect with available PDO drivers (mysql preferred)
            $this->connectSql();
        }
    }

    private function connectSql() {
        try {
            $port = defined('DB_PORT') && DB_PORT ? DB_PORT : '';
            $portPart = $port ? ";port={$port}" : '';
            $dsn = "mysql:host={$this->host}{$portPart};dbname={$this->db_name};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            // support SSL CA if provided
            if (defined('DB_SSL_CA') && DB_SSL_CA) {
                $options[PDO::MYSQL_ATTR_SSL_CA] = DB_SSL_CA;
            }

            $this->pdo = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $e) {
            // fallback to sqlite if PDO is available but mysql not reachable
            error_log('SQL connection failed: ' . $e->getMessage());
            $this->connectSQLiteFallback();
        }
    }

    private function connectMongo() {
        try {
            // Prefer the MongoDB\Client from the extension/pecl library
            if (class_exists('MongoDB\\Client')) {
                $port = defined('DB_PORT') && DB_PORT ? DB_PORT : '27017';
                $user = urlencode($this->username);
                $pass = urlencode($this->password);
                $auth = $this->username !== '' ? "{$user}:{$pass}@" : '';
                $uri = "mongodb://{$auth}{$this->host}:{$port}/{$this->db_name}";
                $this->mongo = new MongoClient($uri, [], ['typeMap' => ['root' => 'array','document' => 'array']]);
                // ensure collections exist and indexes
                $this->ensureMongoSchema();
            } else {
                throw new Exception('MongoDB\Client class not found. Install mongodb extension or driver.');
            }
        } catch (Exception $e) {
            error_log('MongoDB connection failed: ' . $e->getMessage());
            throw $e;
        }
    }

    private function connectSQLiteFallback() {
        try {
            $dataDir = __DIR__ . '/../data';
            if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
            $sqliteFile = $dataDir . '/cms.sqlite';
            $dsn = 'sqlite:' . $sqliteFile;
            $this->pdo = new PDO($dsn, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            $this->ensureSqliteSchema();
        } catch (PDOException $e) {
            error_log('SQLite fallback failed: ' . $e->getMessage());
            throw $e;
        }
    }

    private function ensureSqliteSchema() {
        $this->pdo->exec("CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            name TEXT,
            full_name TEXT,
            role TEXT DEFAULT 'user',
            phone TEXT,
            address TEXT,
            city TEXT,
            state TEXT,
            zip TEXT,
            bio TEXT,
            profile_completed INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )");

        $this->pdo->exec("CREATE TABLE IF NOT EXISTS settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            setting_key TEXT NOT NULL UNIQUE,
            setting_value TEXT
        )");

        $this->pdo->exec("CREATE TABLE IF NOT EXISTS login_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            session_id TEXT UNIQUE NOT NULL,
            ip_address TEXT NOT NULL,
            user_agent TEXT NOT NULL,
            login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
            logout_time DATETIME NULL,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");

        $this->pdo->exec("CREATE TABLE IF NOT EXISTS notices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            category TEXT DEFAULT 'general',
            priority TEXT DEFAULT 'medium',
            target_audience TEXT DEFAULT 'all',
            is_published INTEGER DEFAULT 1,
            created_by INTEGER NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at DATETIME NULL,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
        )");

        $this->pdo->exec("CREATE TABLE IF NOT EXISTS notice_reads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            notice_id INTEGER NOT NULL,
            read_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (notice_id) REFERENCES notices(id) ON DELETE CASCADE,
            UNIQUE(user_id, notice_id)
        )");

        $stmt = $this->pdo->prepare('SELECT COUNT(1) as cnt FROM settings WHERE setting_key = ?');
        $stmt->execute(['app_name']);
        $row = $stmt->fetch();
        if (empty($row) || $row['cnt'] == 0) {
            $ins = $this->pdo->prepare('INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES (?,?)');
            $ins->execute(['app_name', defined('APP_NAME') ? APP_NAME : 'CMS Core']);
            $ins->execute(['primary_color', '#4f46e5']);
            $ins->execute(['secondary_color', '#06b6d4']);
            $ins->execute(['text_color_light', '#ffffff']);
            $ins->execute(['text_color_dark', '#111827']);
        }
    }

    private function ensureMongoSchema() {
        try {
            $db = $this->mongo->selectDatabase($this->db_name);
            // collections
            $collections = ['users', 'settings', 'login_sessions', 'notices', 'notice_reads'];
            foreach ($collections as $col) {
                $cols = $db->listCollections();
                // create collection if missing
                $found = false;
                foreach ($cols as $c) {
                    if ($c->getName() === $col) { $found = true; break; }
                }
                if (!$found) {
                    $db->createCollection($col);
                }
            }
            // indexes for uniqueness and lookups
            $db->users->createIndex(['email' => 1], ['unique' => true]);
            $db->login_sessions->createIndex(['session_id' => 1], ['unique' => true]);
            $db->notice_reads->createIndex(['user_id' => 1, 'notice_id' => 1], ['unique' => true]);

            // seed default settings if missing
            $existing = $db->settings->findOne(['setting_key' => 'app_name']);
            if (!$existing) {
                $db->settings->insertMany([
                    ['setting_key' => 'app_name', 'setting_value' => defined('APP_NAME') ? APP_NAME : 'CMS Core'],
                    ['setting_key' => 'primary_color', 'setting_value' => '#4f46e5'],
                    ['setting_key' => 'secondary_color', 'setting_value' => '#06b6d4'],
                    ['setting_key' => 'text_color_light', 'setting_value' => '#ffffff'],
                    ['setting_key' => 'text_color_dark', 'setting_value' => '#111827']
                ]);
            }
        } catch (Exception $e) {
            error_log('ensureMongoSchema error: ' . $e->getMessage());
            throw $e;
        }
    }
}
