<?php
define('APP_NAME', 'CMS-core');
define('DB_DRIVER', 'mysql');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'cms');
define('DB_USER', 'root'); 
define('DB_PASS', ''); 
?>
