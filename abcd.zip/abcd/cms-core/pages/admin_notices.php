<?php
// Ensure user is logged in and is admin
if (!Auth::isLoggedIn() || $_SESSION['role'] !== 'admin') {
    header("Location: index.php?page=login");
    exit;
}

require_once 'includes/sidebar.php';

$notices = new Notices();
$action = $_GET['action'] ?? '';
$noticeId = $_GET['notice_id'] ?? null;
$success = $_GET['success'] ?? '';
$error = $_GET['error'] ?? '';
$page = $_GET['page_num'] ?? 1;
$filterCategory = $_GET['category'] ?? 'all';
$searchQuery = $_GET['search'] ?? '';

// Handle form submission for creating/updating notice
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $postAction = $_POST['action'];
    
    if ($postAction === 'create') {
        $title = $_POST['title'];
        $content = $_POST['content'];
        $category = $_POST['category'];
        $priority = $_POST['priority'];
        $targetAudience = $_POST['target_audience'];
        $expiresAt = !empty($_POST['expires_at']) ? $_POST['expires_at'] : null;
        $isPublished = isset($_POST['is_published']) ? 1 : 0;

        if ($notices->create($title, $content, $category, $priority, $targetAudience, $_SESSION['user_id'], $expiresAt, $isPublished)) {
            header("Location: index.php?page=admin_notices&success=created");
            exit;
        } else {
            $error = "Failed to create notice";
        }
    } elseif ($postAction === 'update' && $noticeId) {
        // ... existing update code ...
    } elseif ($postAction === 'delete' && $noticeId) {
        // ... existing delete code ...
    }
}

// Handle bulk actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_action'])) {
    $bulkAction = $_POST['bulk_action'];
    $selectedIds = $_POST['selected_notices'] ?? [];
    
    if (!empty($selectedIds)) {
        if ($bulkAction === 'delete') {
            if ($notices->bulkDelete($selectedIds)) {
                $success = 'bulk_deleted';
            } else {
                $error = "Failed to delete selected notices";
            }
        } elseif ($bulkAction === 'publish') {
            if ($notices->bulkPublish($selectedIds, true)) {
                $success = 'bulk_published';
            } else {
                $error = "Failed to publish selected notices";
            }
        } elseif ($bulkAction === 'unpublish') {
            if ($notices->bulkPublish($selectedIds, false)) {
                $success = 'bulk_unpublished';
            } else {
                $error = "Failed to unpublish selected notices";
            }
        }
    } else {
        $error = "No notices selected";
    }
}

// Handle duplicate action
if ($action === 'duplicate' && $noticeId) {
    if ($notices->duplicateNotice($noticeId)) {
        header("Location: index.php?page=admin_notices&success=duplicated");
        exit;
    } else {
        $error = "Failed to duplicate notice";
    }
}

$allNotices = $notices->getAllNotices($page, 10, $filterCategory !== 'all' ? $filterCategory : null, $searchQuery);
$totalCount = $notices->getTotalCount($filterCategory !== 'all' ? $filterCategory : null, $searchQuery);
$totalPages = ceil($totalCount / 10);
$currentNotice = ($action === 'edit' && $noticeId) ? $notices->getNoticeById($noticeId) : null;

// Get statistics
$stats = $notices->getNoticeStats();
?>

<div class="dashboard-layout">
    <main class="dashboard-content">
        <!-- Statistics Dashboard -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
            <div style="
                background: var(--glass);
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 12px;
                padding: 20px;
                text-align: center;
            ">
                <div style="font-size: 2rem; margin-bottom: 10px;">📢</div>
                <div style="font-size: 2rem; font-weight: bold; color: var(--primary);"><?= $stats['total_notices'] ?? 0 ?></div>
                <div style="color: var(--text-light); opacity: 0.8;">Total Notices</div>
            </div>
            
            <div style="
                background: var(--glass);
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 12px;
                padding: 20px;
                text-align: center;
            ">
                <div style="font-size: 2rem; margin-bottom: 10px;">📖</div>
                <div style="font-size: 2rem; font-weight: bold; color: #4CAF50;"><?= $stats['published_notices'] ?? 0 ?></div>
                <div style="color: var(--text-light); opacity: 0.8;">Published</div>
            </div>
            
            <div style="
                background: var(--glass);
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 12px;
                padding: 20px;
                text-align: center;
            ">
                <div style="font-size: 2rem; margin-bottom: 10px;">👁️</div>
                <div style="font-size: 2rem; font-weight: bold; color: #2196F3;"><?= $stats['total_reads'] ?? 0 ?></div>
                <div style="color: var(--text-light); opacity: 0.8;">Total Reads</div>
            </div>
            
            <div style="
                background: var(--glass);
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 12px;
                padding: 20px;
                text-align: center;
            ">
                <div style="font-size: 2rem; margin-bottom: 10px;">🆕</div>
                <div style="font-size: 2rem; font-weight: bold; color: #FF9800;"><?= $stats['recent_notices'] ?? 0 ?></div>
                <div style="color: var(--text-light); opacity: 0.8;">This Week</div>
            </div>
        </div>

        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <div>
                <h1 style="margin: 0; font-size: 2rem; color: var(--text-light);">📢 Manage Notices</h1>
                <p style="opacity: 0.7; color: var(--text-light); margin-top: 5px;">Create and manage system announcements</p>
            </div>
            <button onclick="toggleCreateForm()" style="
                background: var(--primary);
                color: white;
                padding: 10px 20px;
                border-radius: 8px;
                border: none;
                cursor: pointer;
                font-weight: 500;
                transition: all 0.2s;
            " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                ➕ Create New Notice
            </button>
        </div>

        <!-- Success/Error Messages -->
        <?php if ($success): ?>
            <div style="
                background: rgba(76, 175, 80, 0.2);
                border: 2px solid #4CAF50;
                color: #A5D6A7;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
            ">
                ✅ 
                <?php
                if ($success === 'created') echo 'Notice created successfully!';
                elseif ($success === 'updated') echo 'Notice updated successfully!';
                elseif ($success === 'deleted') echo 'Notice deleted successfully!';
                elseif ($success === 'duplicated') echo 'Notice duplicated successfully!';
                elseif ($success === 'bulk_deleted') echo 'Selected notices deleted successfully!';
                elseif ($success === 'bulk_published') echo 'Selected notices published successfully!';
                elseif ($success === 'bulk_unpublished') echo 'Selected notices unpublished successfully!';
                ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div style="
                background: rgba(255, 107, 107, 0.2);
                border: 2px solid #ff6b6b;
                color: #FF8A80;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 20px;
            ">
                ❌ <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <!-- Create/Edit Form -->
        <div id="createForm" style="
            background: var(--glass);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            display: <?= ($action === 'edit' && $currentNotice) ? 'block' : 'none' ?>;
        ">
            <h3 style="margin-top: 0; color: var(--text-light);">
                <?= ($action === 'edit' && $currentNotice) ? 'Edit Notice' : 'Create New Notice' ?>
            </h3>

            <form method="POST" style="display: grid; gap: 15px;">
                <input type="hidden" name="action" value="<?= ($action === 'edit' && $currentNotice) ? 'update' : 'create' ?>">

                <!-- Title -->
                <div>
                    <label style="display: block; margin-bottom: 8px; color: var(--text-light); font-weight: 500;">
                        Notice Title *
                    </label>
                    <input 
                        type="text" 
                        name="title" 
                        required
                        value="<?= $currentNotice ? htmlspecialchars($currentNotice['title']) : '' ?>"
                        placeholder="e.g., Exam Schedule Update"
                        style="
                            width: 100%;
                            padding: 10px 15px;
                            background: rgba(255,255,255,0.1);
                            border: 1px solid rgba(255,255,255,0.2);
                            border-radius: 8px;
                            color: var(--text-light);
                            font-family: inherit;
                            box-sizing: border-box;
                        "
                    >
                </div>

                <!-- Content -->
                <div>
                    <label style="display: block; margin-bottom: 8px; color: var(--text-light); font-weight: 500;">
                        Notice Content *
                    </label>
                    <textarea 
                        name="content" 
                        required
                        placeholder="Enter the detailed notice content..."
                        rows="6"
                        style="
                            width: 100%;
                            padding: 10px 15px;
                            background: rgba(255,255,255,0.1);
                            border: 1px solid rgba(255,255,255,0.2);
                            border-radius: 8px;
                            color: var(--text-light);
                            font-family: inherit;
                            box-sizing: border-box;
                            resize: vertical;
                        "
                    ><?= $currentNotice ? htmlspecialchars($currentNotice['content']) : '' ?></textarea>
                </div>

                <!-- Category and Priority -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-light); font-weight: 500;">
                            Category
                        </label>
                        <select name="category" style="
                            width: 100%;
                            padding: 10px 15px;
                            background: rgba(255,255,255,0.1);
                            border: 1px solid rgba(255,255,255,0.2);
                            border-radius: 8px;
                            color: var(--text-light);
                            font-family: inherit;
                            box-sizing: border-box;
                        ">
                            <option value="general" <?= $currentNotice && $currentNotice['category'] === 'general' ? 'selected' : '' ?>>General</option>
                            <option value="urgent" <?= $currentNotice && $currentNotice['category'] === 'urgent' ? 'selected' : '' ?>>Urgent</option>
                            <option value="academic" <?= $currentNotice && $currentNotice['category'] === 'academic' ? 'selected' : '' ?>>Academic</option>
                            <option value="admin" <?= $currentNotice && $currentNotice['category'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                            <option value="event" <?= $currentNotice && $currentNotice['category'] === 'event' ? 'selected' : '' ?>>Event</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-light); font-weight: 500;">
                            Priority
                        </label>
                        <select name="priority" style="
                            width: 100%;
                            padding: 10px 15px;
                            background: rgba(255,255,255,0.1);
                            border: 1px solid rgba(255,255,255,0.2);
                            border-radius: 8px;
                            color: var(--text-light);
                            font-family: inherit;
                            box-sizing: border-box;
                        ">
                            <option value="low" <?= $currentNotice && $currentNotice['priority'] === 'low' ? 'selected' : '' ?>>Low</option>
                            <option value="medium" <?= $currentNotice && $currentNotice['priority'] === 'medium' ? 'selected' : '' ?>>Medium</option>
                            <option value="high" <?= $currentNotice && $currentNotice['priority'] === 'high' ? 'selected' : '' ?>>High</option>
                            <option value="critical" <?= $currentNotice && $currentNotice['priority'] === 'critical' ? 'selected' : '' ?>>Critical</option>
                        </select>
                    </div>
                </div>

                <!-- Target Audience and Expiry -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-light); font-weight: 500;">
                            Target Audience
                        </label>
                        <select name="target_audience" style="
                            width: 100%;
                            padding: 10px 15px;
                            background: rgba(255,255,255,0.1);
                            border: 1px solid rgba(255,255,255,0.2);
                            border-radius: 8px;
                            color: var(--text-light);
                            font-family: inherit;
                            box-sizing: border-box;
                        ">
                            <option value="all" <?= $currentNotice && $currentNotice['target_audience'] === 'all' ? 'selected' : '' ?>>All Users</option>
                            <option value="students" <?= $currentNotice && $currentNotice['target_audience'] === 'students' ? 'selected' : '' ?>>Students Only</option>
                            <option value="teachers" <?= $currentNotice && $currentNotice['target_audience'] === 'teachers' ? 'selected' : '' ?>>Teachers Only</option>
                            <option value="admin" <?= $currentNotice && $currentNotice['target_audience'] === 'admin' ? 'selected' : '' ?>>Admin Only</option>
                        </select>
                    </div>

                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-light); font-weight: 500;">
                            Expires At (Optional)
                        </label>
                        <input 
                            type="datetime-local" 
                            name="expires_at"
                            value="<?= $currentNotice && $currentNotice['expires_at'] ? date('Y-m-d\TH:i', strtotime($currentNotice['expires_at'])) : '' ?>"
                            style="
                                width: 100%;
                                padding: 10px 15px;
                                background: rgba(255,255,255,0.1);
                                border: 1px solid rgba(255,255,255,0.2);
                                border-radius: 8px;
                                color: var(--text-light);
                                font-family: inherit;
                                box-sizing: border-box;
                            "
                        >
                    </div>
                </div>

                <!-- Published Checkbox -->
                <div>
                    <label style="display: flex; align-items: center; gap: 10px; color: var(--text-light); font-weight: 500;">
                        <input 
                            type="checkbox" 
                            name="is_published" 
                            value="1"
                            <?php if ($currentNotice && $currentNotice['is_published']): ?>
                                checked 
                            <?php elseif (!$currentNotice): ?>
                                checked
                            <?php endif; ?>
                        >
                        Publish Immediately
                    </label>
                </div>

                <!-- Buttons -->
                <div style="display: flex; gap: 10px; margin-top: 15px;">
                    <button type="submit" style="
                        flex: 1;
                        padding: 12px 20px;
                        background: var(--primary);
                        color: white;
                        border: none;
                        border-radius: 8px;
                        cursor: pointer;
                        font-weight: 600;
                        transition: all 0.2s;
                    " onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform='scale(1)'">
                        <?= ($action === 'edit' && $currentNotice) ? '✏️ Update Notice' : '➕ Create Notice' ?>
                    </button>
                    <?php if ($action === 'edit' && $currentNotice): ?>
                        <a href="index.php?page=admin_notices" style="
                            padding: 12px 20px;
                            background: rgba(255,255,255,0.1);
                            color: var(--text-light);
                            border: 1px solid rgba(255,255,255,0.2);
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                            transition: all 0.2s;
                            text-decoration: none;
                            display: inline-block;
                        " onmouseover="this.style.background='rgba(255,255,255,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.1)'">
                            Cancel
                        </a>
                    <?php else: ?>
                        <button type="button" onclick="toggleCreateForm()" style="
                            padding: 12px 20px;
                            background: rgba(255,255,255,0.1);
                            color: var(--text-light);
                            border: 1px solid rgba(255,255,255,0.2);
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                            transition: all 0.2s;
                        " onmouseover="this.style.background='rgba(255,255,255,0.15)'" onmouseout="this.style.background='rgba(255,255,255,0.1)'">
                            Cancel
                        </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Filter Bar -->
        <div style="display: flex; gap: 10px; margin-bottom: 25px; align-items: center;">
            <form method="GET" style="display: flex; gap: 10px;">
                <input type="hidden" name="page" value="admin_notices">
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Search notices..." 
                    value="<?= htmlspecialchars($searchQuery) ?>"
                    style="
                        padding: 10px 15px;
                        background: rgba(255,255,255,0.1);
                        border: 1px solid rgba(255,255,255,0.2);
                        border-radius: 8px;
                        color: var(--text-light);
                        font-family: inherit;
                        width: 250px;
                    "
                >
                <button type="submit" style="
                    padding: 10px 20px;
                    background: var(--primary);
                    color: white;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 500;
                    transition: all 0.2s;
                " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    Search
                </button>
            </form>

            <form method="GET" style="display: flex;">
                <input type="hidden" name="page" value="admin_notices">
                <select name="category" onchange="this.form.submit()" style="
                    padding: 10px 15px;
                    background: rgba(255,255,255,0.1);
                    border: 1px solid rgba(255,255,255,0.2);
                    border-radius: 8px;
                    color: var(--text-light);
                    cursor: pointer;
                    font-family: inherit;
                ">
                    <option value="all">All Categories</option>
                    <option value="urgent" <?= $filterCategory === 'urgent' ? 'selected' : '' ?>>Urgent</option>
                    <option value="academic" <?= $filterCategory === 'academic' ? 'selected' : '' ?>>Academic</option>
                    <option value="admin" <?= $filterCategory === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="event" <?= $filterCategory === 'event' ? 'selected' : '' ?>>Events</option>
                    <option value="general" <?= $filterCategory === 'general' ? 'selected' : '' ?>>General</option>
                </select>
            </form>
        </div>

        <!-- Bulk Actions Bar -->
        <div id="bulkActions" style="display: none; background: rgba(255,152,0,0.1); border: 1px solid #FF9800; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
            <form method="POST" id="bulkForm" style="display: flex; align-items: center; gap: 15px;">
                <span style="color: var(--text-light); font-weight: 500;">Selected: <span id="selectedCount">0</span> notices</span>
                <button type="submit" name="bulk_action" value="publish" style="
                    padding: 8px 16px;
                    background: #4CAF50;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-weight: 500;
                ">📢 Publish</button>
                <button type="submit" name="bulk_action" value="unpublish" style="
                    padding: 8px 16px;
                    background: #FF9800;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-weight: 500;
                ">📁 Unpublish</button>
                <button type="submit" name="bulk_action" value="delete" style="
                    padding: 8px 16px;
                    background: #F44336;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-weight: 500;
                " onclick="return confirm('Delete selected notices?')">🗑️ Delete</button>
            </form>
        </div>

        <!-- Notices Table -->
        <div style="
            background: var(--glass);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            overflow: hidden;
        ">
            <?php if (empty($allNotices)): ?>
                <div style="padding: 40px; text-align: center; color: var(--text-light);">
                    <div style="font-size: 2rem; margin-bottom: 10px;">📭</div>
                    <p>No notices found. Create one to get started!</p>
                </div>
            <?php else: ?>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                            <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600; width: 40px;">
                                <input type="checkbox" id="selectAll" style="cursor: pointer;">
                            </th>
                            <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600;">Title</th>
                            <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600; width: 100px;">Category</th>
                            <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600; width: 80px;">Priority</th>
                            <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600; width: 80px;">Status</th>
                            <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600; width: 80px;">Reads</th>
                            <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600; width: 100px;">Created</th>
                            <th style="padding: 15px; text-align: center; color: var(--text-light); font-weight: 600; width: 120px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($allNotices as $notice): ?>
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                                <td style="padding: 15px;">
                                    <input type="checkbox" name="selected_notices[]" value="<?= $notice['id'] ?>" class="notice-checkbox" style="cursor: pointer;">
                                </td>
                                <td style="padding: 15px; color: var(--text-light);">
                                    <strong><?= htmlspecialchars(substr($notice['title'], 0, 40)) ?></strong>
                                </td>
                                <td style="padding: 15px; color: var(--text-light);">
                                    <span style="
                                        display: inline-block;
                                        padding: 4px 10px;
                                        background: rgba(255,255,255,0.1);
                                        border-radius: 6px;
                                        font-size: 0.85rem;
                                    ">
                                        <?= ucfirst($notice['category']) ?>
                                    </span>
                                </td>
                                <td style="padding: 15px; color: var(--text-light);">
                                    <span style="
                                        display: inline-block;
                                        padding: 4px 10px;
                                        background: <?php
                                            $priorityColor = [
                                                'critical' => 'rgba(255, 68, 68, 0.2)',
                                                'high' => 'rgba(255, 152, 0, 0.2)',
                                                'medium' => 'rgba(33, 150, 243, 0.2)',
                                                'low' => 'rgba(76, 175, 80, 0.2)'
                                            ];
                                            echo $priorityColor[$notice['priority']] ?? 'rgba(255,255,255,0.1)';
                                        ?>;
                                        border-radius: 6px;
                                        font-size: 0.85rem;
                                    ">
                                        <?= ucfirst($notice['priority']) ?>
                                    </span>
                                </td>
                                <td style="padding: 15px; color: var(--text-light);">
                                    <span style="
                                        display: inline-block;
                                        padding: 4px 10px;
                                        background: <?= $notice['is_published'] ? 'rgba(76, 175, 80, 0.2)' : 'rgba(158, 158, 158, 0.2)' ?>;
                                        border-radius: 6px;
                                        font-size: 0.85rem;
                                    ">
                                        <?= $notice['is_published'] ? 'Published' : 'Draft' ?>
                                    </span>
                                </td>
                                <td style="padding: 15px; color: var(--text-light); font-size: 0.9rem;">
                                    <?= $notice['read_count'] ?? 0 ?>
                                </td>
                                <td style="padding: 15px; color: var(--text-light); font-size: 0.9rem;">
                                    <?= date('M d, Y', strtotime($notice['created_at'])) ?>
                                </td>
                                <td style="padding: 15px; text-align: center;">
                                    <a href="index.php?page=admin_notices&action=edit&notice_id=<?= $notice['id'] ?>" style="
                                        display: inline-block;
                                        padding: 6px 12px;
                                        background: var(--primary);
                                        color: white;
                                        border-radius: 6px;
                                        text-decoration: none;
                                        font-size: 0.85rem;
                                        margin-right: 5px;
                                        transition: all 0.2s;
                                    " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                        ✏️
                                    </a>
                                    <a href="index.php?page=admin_notices&action=duplicate&notice_id=<?= $notice['id'] ?>" style="
                                        display: inline-block;
                                        padding: 6px 12px;
                                        background: #2196F3;
                                        color: white;
                                        border-radius: 6px;
                                        text-decoration: none;
                                        font-size: 0.85rem;
                                        margin-right: 5px;
                                        transition: all 0.2s;
                                    " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                        📋
                                    </a>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this notice?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="notice_id" value="<?= $notice['id'] ?>">
                                        <button type="submit" style="
                                            padding: 6px 12px;
                                            background: #ff6b6b;
                                            color: white;
                                            border: none;
                                            border-radius: 6px;
                                            font-size: 0.85rem;
                                            cursor: pointer;
                                            transition: all 0.2s;
                                        " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                            🗑️
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div style="padding: 15px; border-top: 1px solid rgba(255,255,255,0.1); display: flex; justify-content: center; gap: 10px;">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <a href="index.php?page=admin_notices&page_num=<?= $i ?>&category=<?= $filterCategory ?>" style="
                                padding: 8px 12px;
                                background: <?= $i === $page ? 'var(--primary)' : 'rgba(255,255,255,0.1)' ?>;
                                color: var(--text-light);
                                border: 1px solid rgba(255,255,255,0.2);
                                border-radius: 6px;
                                text-decoration: none;
                                cursor: pointer;
                                transition: all 0.2s;
                            " onmouseover="this.style.background='rgba(255,255,255,0.15)'" onmouseout="this.style.background='<?= $i === $page ? 'var(--primary)' : 'rgba(255,255,255,0.1)' ?>'">
                                <?= $i ?>
                            </a>
                        <?php endfor; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </main>
</div>

<script>
function toggleCreateForm() {
    const form = document.getElementById('createForm');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

// Bulk actions functionality
document.addEventListener('DOMContentLoaded', function() {
    const selectAllCheckbox = document.getElementById('selectAll');
    const noticeCheckboxes = document.querySelectorAll('.notice-checkbox');
    const bulkActions = document.getElementById('bulkActions');
    const selectedCount = document.getElementById('selectedCount');
    
    // Select all functionality
    selectAllCheckbox.addEventListener('change', function() {
        noticeCheckboxes.forEach(checkbox => {
            checkbox.checked = this.checked;
        });
        updateBulkActions();
    });
    
    // Individual checkbox change
    noticeCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const checkedBoxes = document.querySelectorAll('.notice-checkbox:checked');
            selectAllCheckbox.checked = checkedBoxes.length === noticeCheckboxes.length;
            selectAllCheckbox.indeterminate = checkedBoxes.length > 0 && checkedBoxes.length < noticeCheckboxes.length;
            updateBulkActions();
        });
    });
    
    function updateBulkActions() {
        const checkedBoxes = document.querySelectorAll('.notice-checkbox:checked');
        if (checkedBoxes.length > 0) {
            bulkActions.style.display = 'block';
            selectedCount.textContent = checkedBoxes.length;
        } else {
            bulkActions.style.display = 'none';
        }
    }
});
</script>
