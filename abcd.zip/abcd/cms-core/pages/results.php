<?php
$db = (new Database())->pdo;
$sid = $_SESSION['user_id'];

// Check Payment Status first (Business Rule)
$check = $db->prepare("SELECT payment_status FROM applications WHERE user_id = ?");
$check->execute([$sid]);
$payment = $check->fetchColumn();

if ($payment !== 'paid') {
    echo "<div class='card' style='border-left: 5px solid red;'>
            <h3>🔒 Results Locked</h3>
            <p>Your academic results are hidden. Please visit the finance department to clear your dues.</p>
          </div>";
} else {
    $stmt = $db->prepare("SELECT * FROM results WHERE student_id = ?");
    $stmt->execute([$sid]);
    $rows = $stmt->fetchAll();
    
    echo "<h2>My Academic Performance</h2>";
    echo "<div style='display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:20px;'>";
    foreach($rows as $r) {
        echo "<div class='card'>
                <h4 style='margin:0;'>{$r['subject']}</h4>
                <p style='font-size:2rem; font-weight:800; color:var(--accent);'>{$r['grade']}</p>
                <p>Marks: {$r['marks']}</p>
              </div>";
    }
    if(empty($rows)) echo "<p>No results published yet.</p>";
    echo "</div>";
}
?>
