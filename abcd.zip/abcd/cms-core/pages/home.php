<section class="hero">
    <h1 style="font-size: 4rem; margin:0;">Empowering <span style="color:var(--accent)">Excellence</span></h1>
    <p style="font-size: 1.2rem; max-width: 600px; opacity: 0.9;">Nepal's leading digital campus platform for students and faculty. Join over 5,000+ scholars today.</p>
    <div style="margin-top: 30px; display:flex; gap:15px;">
        <a href="index.php?page=apply" class="btn btn-primary">Online Admission</a>
        <a href="index.php?page=login" class="btn" style="border: 1px solid white; color:white;">Student Portal</a>
    </div>
</section>

<section style="padding: 60px 10%; display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 30px;">
    <div class="card" style="text-align: center;">
        <h2 style="color:var(--accent)">01.</h2>
        <h3>Apply Online</h3>
        <p>Submit your SEE details and documents through our secure portal.</p>
    </div>
    <div class="card" style="text-align: center;">
        <h2 style="color:var(--accent)">02.</h2>
        <h3>Entrance Exam</h3>
        <p>Take the computer-based entrance test from anywhere in the world.</p>
    </div>
    <div class="card" style="text-align: center;">
        <h2 style="color:var(--accent)">03.</h2>
        <h3>Get Admitted</h3>
        <p>Instant results and digital admit cards for successful candidates.</p>
    </div>
</section>
