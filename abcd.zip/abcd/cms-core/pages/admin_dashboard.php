<?php require_once __DIR__ . '/../includes/header.php'; ?>
<h2>Admin Dashboard</h2>
<p>Protected area.</p>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
