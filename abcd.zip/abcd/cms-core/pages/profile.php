<?php
// Profile Page - Users can edit their details and change password
// Protected page - Auth::isLoggedIn() already checked in index.php

require_once 'includes/sidebar.php';

$db = (new Database())->pdo;
$userId = $_SESSION['user_id'];

// Handle form submissions
$message = '';
$messageType = '';

// Update Profile
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    if (!Security::checkCsrf($_POST['csrf_token'] ?? '')) {
        $message = 'Security token invalid';
        $messageType = 'error';
    } else {
        try {
            $stmt = $db->prepare("UPDATE users SET name=?, phone=?, address=?, city=?, state=?, zip=?, bio=?, profile_completed=1, updated_at=CURRENT_TIMESTAMP WHERE id=?");
            $stmt->execute([
                Security::safe($_POST['name']),
                Security::safe($_POST['phone']),
                Security::safe($_POST['address']),
                Security::safe($_POST['city']),
                Security::safe($_POST['state']),
                Security::safe($_POST['zip']),
                Security::safe($_POST['bio']),
                $userId
            ]);
            
            // Update session
            $_SESSION['name'] = $_POST['name'];
            $_SESSION['profile_completed'] = 1;
            
            $message = 'Profile updated successfully!';
            $messageType = 'success';
        } catch (Exception $e) {
            $message = 'Error updating profile: ' . $e->getMessage();
            $messageType = 'error';
        }
    }
}

// Change Password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    if (!Security::checkCsrf($_POST['csrf_token'] ?? '')) {
        $message = 'Security token invalid';
        $messageType = 'error';
    } else {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        // Get current password hash
        $stmt = $db->prepare("SELECT password FROM users WHERE id=?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($currentPassword, $user['password'])) {
            $message = 'Current password is incorrect';
            $messageType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'Passwords do not match';
            $messageType = 'error';
        } elseif (strlen($newPassword) < 6) {
            $message = 'Password must be at least 6 characters';
            $messageType = 'error';
        } else {
            try {
                $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
                $stmt = $db->prepare("UPDATE users SET password=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                $stmt->execute([$hashedPassword, $userId]);
                
                $message = 'Password changed successfully!';
                $messageType = 'success';
            } catch (Exception $e) {
                $message = 'Error changing password: ' . $e->getMessage();
                $messageType = 'error';
            }
        }
    }
}

// Fetch current user data
$stmt = $db->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$userId]);
$user = $stmt->fetch();
?>

<div class="dashboard-layout">
    <main class="dashboard-content">
        <!-- Header -->
        <div style="margin-bottom: 2rem;">
            <h1 style="color: var(--text-light); margin: 0;">👤 My Profile</h1>
            <p style="opacity: 0.7; color: var(--text-light);">Manage your account information and security settings</p>
        </div>

        <!-- Messages -->
        <?php if ($message): ?>
            <div style="
                background: <?php echo $messageType === 'success' ? 'rgba(76, 175, 80, 0.2)' : 'rgba(255, 77, 77, 0.2)'; ?>;
                border: 1px solid <?php echo $messageType === 'success' ? '#4CAF50' : '#ff4d4d'; ?>;
                color: <?php echo $messageType === 'success' ? '#90EE90' : '#ff9999'; ?>;
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1.5rem;
                font-size: 0.95rem;
            ">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Profile Information Section -->
        <div class="glass-panel" style="margin-bottom: 2rem;">
            <h3 style="color: var(--primary); margin-top: 0;">📝 Profile Information</h3>
            <p style="opacity: 0.7; color: var(--text-light); font-size: 0.9rem;">
                <?php if ($user['profile_completed']): ?>
                    Your profile is complete ✓
                <?php else: ?>
                    ⚠️ Please complete your profile to access all features
                <?php endif; ?>
            </p>

            <form method="POST" style="display: grid; gap: 1rem;">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(Security::csrfToken()); ?>">
                <input type="hidden" name="action" value="update_profile">

                <!-- Email (Read-only) -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Email (Cannot be changed)</label>
                    <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly 
                           style="width: 100%; padding: 10px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); cursor: not-allowed; opacity: 0.6;">
                </div>

                <!-- Name -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Full Name *</label>
                    <input type="text" name="name" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required
                           placeholder="Your full name"
                           style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                </div>

                <!-- Phone -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Phone Number</label>
                    <input type="tel" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                           placeholder="Your phone number"
                           style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                </div>

                <!-- Address -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Address</label>
                    <input type="text" name="address" value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>"
                           placeholder="Street address"
                           style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                </div>

                <!-- City, State, Zip -->
                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">City</label>
                        <input type="text" name="city" value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>"
                               placeholder="City"
                               style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">State</label>
                        <input type="text" name="state" value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>"
                               placeholder="State"
                               style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">ZIP Code</label>
                        <input type="text" name="zip" value="<?php echo htmlspecialchars($user['zip'] ?? ''); ?>"
                               placeholder="ZIP code"
                               style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                    </div>
                </div>

                <!-- Bio -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Bio / About You</label>
                    <textarea name="bio" placeholder="Tell us about yourself..."
                              style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none; min-height: 100px; resize: vertical; font-family: inherit;"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                </div>

                <button type="submit" class="btn-primary" style="width: 100%; padding: 12px; font-size: 1rem;">
                    💾 Save Profile
                </button>
            </form>
        </div>

        <!-- Change Password Section -->
        <div class="glass-panel">
            <h3 style="color: var(--primary); margin-top: 0;">🔐 Change Password</h3>
            <p style="opacity: 0.7; color: var(--text-light); font-size: 0.9rem;">Update your password to keep your account secure</p>

            <form method="POST" style="display: grid; gap: 1rem;">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(Security::csrfToken()); ?>">
                <input type="hidden" name="action" value="change_password">

                <!-- Current Password -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Current Password *</label>
                    <input type="password" name="current_password" required
                           placeholder="Enter your current password"
                           style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                </div>

                <!-- New Password -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">New Password *</label>
                    <input type="password" name="new_password" required
                           placeholder="Enter new password (min 6 characters)"
                           style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                </div>

                <!-- Confirm Password -->
                <div>
                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Confirm Password *</label>
                    <input type="password" name="confirm_password" required
                           placeholder="Confirm new password"
                           style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                </div>

                <button type="submit" class="btn-primary" style="width: 100%; padding: 12px; font-size: 1rem;">
                    🔄 Change Password
                </button>
            </form>
        </div>

    </main>
</div>
