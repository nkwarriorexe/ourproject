<?php
// Ensure user is logged in
if (!Auth::isLoggedIn()) {
    header("Location: index.php?page=login");
    exit;
}

require_once 'includes/sidebar.php';

$auth = new Auth();
$sessionManager = new SessionManager();
$sessions = $auth->getActiveSessions($_SESSION['user_id']);
$sessionHistory = $auth->getSessionHistory($_SESSION['user_id'], 10);
?>

<div class="dashboard-layout">
    <main class="dashboard-content">
        <!-- Header -->
        <div style="margin-bottom: 30px;">
            <h1 style="margin: 0; font-size: 2rem; color: var(--text-light);">🔐 Security & Sessions</h1>
            <p style="opacity: 0.7; color: var(--text-light); margin-top: 5px;">Manage your active sessions and login history</p>
        </div>

        <!-- Active Sessions Section -->
        <div style="margin-bottom: 40px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="margin: 0; color: var(--text-light);">Active Sessions (<?= count($sessions) ?>)</h2>
                <?php if (count($sessions) > 1): ?>
                    <form method="GET" onsubmit="return confirm('Log out from ALL devices? You will be logged out immediately.');">
                        <input type="hidden" name="page" value="logout">
                        <input type="hidden" name="subaction" value="all_devices">
                        <button type="submit" style="
                            padding: 10px 20px;
                            background: #ff6b6b;
                            color: white;
                            border: none;
                            border-radius: 8px;
                            cursor: pointer;
                            font-weight: 600;
                            transition: all 0.2s;
                        " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                            🚪 Logout All Devices
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <div style="display: grid; gap: 15px;">
                <?php if (empty($sessions)): ?>
                    <div style="
                        background: var(--glass);
                        backdrop-filter: blur(15px);
                        border: 1px solid rgba(255,255,255,0.1);
                        border-radius: 12px;
                        padding: 30px;
                        text-align: center;
                        color: var(--text-light);
                    ">
                        <p>No active sessions found.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($sessions as $session): ?>
                        <?php
                        $deviceName = SessionManager::getDeviceName($session['user_agent']);
                        $browserName = SessionManager::getBrowserName($session['user_agent']);
                        $isCurrentSession = isset($_SESSION['session_id']) && $_SESSION['session_id'] === $session['session_id'];
                        ?>
                        <div style="
                            background: var(--glass);
                            backdrop-filter: blur(15px);
                            border: 1px solid rgba(255,255,255,0.1);
                            border-radius: 12px;
                            padding: 20px;
                            color: var(--text-light);
                            <?= $isCurrentSession ? 'border-left: 5px solid var(--primary);' : '' ?>
                        ">
                            <div style="display: flex; justify-content: space-between; align-items: start;">
                                <div style="flex: 1;">
                                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                                        <span style="font-size: 1.5rem;">
                                            <?php
                                            if (strpos($session['user_agent'], 'Mobile') !== false) {
                                                echo '📱';
                                            } elseif (strpos($session['user_agent'], 'iPad') !== false) {
                                                echo '📱';
                                            } else {
                                                echo '💻';
                                            }
                                            ?>
                                        </span>
                                        <div>
                                            <h3 style="margin: 0; font-size: 1.1rem;">
                                                <?= htmlspecialchars($deviceName) ?> • <?= htmlspecialchars($browserName) ?>
                                            </h3>
                                            <p style="margin: 5px 0 0; opacity: 0.7; font-size: 0.9rem;">
                                                IP: <?= htmlspecialchars($session['ip_address']) ?>
                                            </p>
                                        </div>
                                    </div>

                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 10px; font-size: 0.9rem;">
                                        <div>
                                            <span style="opacity: 0.6;">Last active:</span>
                                            <br>
                                            <strong><?= date('M d, Y - H:i', strtotime($session['last_activity'])) ?></strong>
                                        </div>
                                        <div>
                                            <span style="opacity: 0.6;">Login time:</span>
                                            <br>
                                            <strong><?= date('M d, Y - H:i', strtotime($session['login_time'])) ?></strong>
                                        </div>
                                    </div>

                                    <?php if ($isCurrentSession): ?>
                                        <div style="
                                            margin-top: 10px;
                                            padding: 8px 12px;
                                            background: rgba(76, 175, 80, 0.2);
                                            border-left: 3px solid #4CAF50;
                                            border-radius: 4px;
                                            color: #A5D6A7;
                                            font-size: 0.85rem;
                                        ">
                                            ✅ This device (current session)
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <?php if (!$isCurrentSession): ?>
                                    <form method="POST" onsubmit="return confirm('Logout from this device?');" style="margin-left: 15px;">
                                        <input type="hidden" name="action" value="logout_device">
                                        <input type="hidden" name="session_id" value="<?= htmlspecialchars($session['id']) ?>">
                                        <button type="submit" style="
                                            padding: 8px 15px;
                                            background: #ff6b6b;
                                            color: white;
                                            border: none;
                                            border-radius: 6px;
                                            cursor: pointer;
                                            font-size: 0.85rem;
                                            transition: all 0.2s;
                                        " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                                            🚪 Logout
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Login History Section -->
        <div>
            <h2 style="margin: 0 0 20px 0; color: var(--text-light);">📊 Login History</h2>

            <div style="
                background: var(--glass);
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 12px;
                overflow: hidden;
            ">
                <?php if (empty($sessionHistory)): ?>
                    <div style="padding: 30px; text-align: center; color: var(--text-light);">
                        <p>No login history available.</p>
                    </div>
                <?php else: ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                                <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600;">Device</th>
                                <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600;">IP Address</th>
                                <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600;">Login Time</th>
                                <th style="padding: 15px; text-align: left; color: var(--text-light); font-weight: 600;">Logout Time</th>
                                <th style="padding: 15px; text-align: center; color: var(--text-light); font-weight: 600;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sessionHistory as $history): ?>
                                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                                    <td style="padding: 15px; color: var(--text-light);">
                                        <span style="
                                            display: inline-block;
                                            padding: 4px 10px;
                                            background: rgba(255,255,255,0.1);
                                            border-radius: 6px;
                                            font-size: 0.9rem;
                                        ">
                                            <?php
                                            if (strpos($history['user_agent'], 'Mobile') !== false) {
                                                echo '📱 Mobile';
                                            } elseif (strpos($history['user_agent'], 'iPad') !== false) {
                                                echo '📱 Tablet';
                                            } else {
                                                echo '💻 Desktop';
                                            }
                                            ?>
                                        </span>
                                    </td>
                                    <td style="padding: 15px; color: var(--text-light); font-family: monospace; font-size: 0.85rem;">
                                        <?= htmlspecialchars($history['ip_address']) ?>
                                    </td>
                                    <td style="padding: 15px; color: var(--text-light);">
                                        <?= date('M d, Y - H:i', strtotime($history['login_time'])) ?>
                                    </td>
                                    <td style="padding: 15px; color: var(--text-light);">
                                        <?php if ($history['logout_time']): ?>
                                            <?= date('M d, Y - H:i', strtotime($history['logout_time'])) ?>
                                        <?php else: ?>
                                            <span style="color: #FFB74D;">--:-- (No logout)</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding: 15px; text-align: center;">
                                        <?php if ($history['is_active']): ?>
                                            <span style="
                                                display: inline-block;
                                                padding: 4px 10px;
                                                background: rgba(76, 175, 80, 0.2);
                                                color: #A5D6A7;
                                                border-radius: 6px;
                                                font-size: 0.85rem;
                                            ">
                                                ✅ Active
                                            </span>
                                        <?php else: ?>
                                            <span style="
                                                display: inline-block;
                                                padding: 4px 10px;
                                                background: rgba(255,255,255,0.1);
                                                color: var(--text-light);
                                                border-radius: 6px;
                                                font-size: 0.85rem;
                                            ">
                                                ⭕ Closed
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Security Tips -->
        <div style="
            background: var(--glass);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 12px;
            padding: 25px;
            margin-top: 30px;
            color: var(--text-light);
        ">
            <h3 style="margin-top: 0; color: var(--text-light);">🛡️ Security Tips</h3>
            <ul style="margin: 0; padding-left: 20px;">
                <li style="margin-bottom: 10px;">Regularly check your active sessions for unauthorized access</li>
                <li style="margin-bottom: 10px;">Logout from other devices when not in use</li>
                <li style="margin-bottom: 10px;">Use 'Logout All Devices' if you suspect unauthorized access</li>
                <li style="margin-bottom: 10px;">Never share your login credentials with anyone</li>
                <li style="margin-bottom: 10px;">Avoid using public WiFi for sensitive account activities</li>
                <li>Report any suspicious login activity immediately to admin</li>
            </ul>
        </div>
    </main>
</div>
