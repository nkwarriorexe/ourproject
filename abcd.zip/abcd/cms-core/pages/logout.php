<?php
require_once __DIR__ . '/../core/Auth.php';

$auth = new Auth();

// Start session to access session variables
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is actually logged in
if (Auth::isLoggedIn()) {
    $auth->logout();
}

// Redirect to login page regardless
header("Location: index.php?page=login&status=logged_out");
exit();
?>