<?php
$db = (new Database())->pdo;
if ($_GET['action'] == 'approve') {
    $stmt = $db->prepare("UPDATE applications SET status='approved' WHERE id=?");
    $stmt->execute([$_GET['id']]);
}
$apps = $db->query("SELECT * FROM applications ORDER BY applied_at DESC")->fetchAll();
?>
<div class="dashboard-layout">
    <?php include 'includes/sidebar.php'; ?>
    <main style="padding: 40px; flex:1;">
        <div class="glass-panel">
            <h2>Admission Applications</h2>
            <table style="width:100%; margin-top:20px; border-collapse:collapse;">
                <tr style="background:var(--primary); color:white;">
                    <th style="padding:10px;">Student</th>
                    <th>Course</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
                <?php foreach($apps as $a): ?>
                <tr style="border-bottom:1px solid #ddd;">
                    <td style="padding:10px;"><?= $a['student_name'] ?></td>
                    <td><?= $a['course'] ?></td>
                    <td><span style="color:<?= $a['status']=='approved'?'green':'orange' ?>"><?= $a['status'] ?></span></td>
                    <td>
                        <?php if($a['status']=='pending'): ?>
                            <a href="index.php?page=applications&action=approve&id=<?= $a['id'] ?>" class="btn btn-gold" style="font-size:0.7rem;">Approve</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </main>
</div>
