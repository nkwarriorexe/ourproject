<?php
// Admin Users Management Page
// Protected page - Auth::isLoggedIn() already checked in index.php

require_once 'includes/sidebar.php';

// Check if user is admin
if ($_SESSION['role'] !== 'admin') {
    echo '<div class="glass-panel" style="color: var(--text-light); text-align: center; padding: 3rem;">
        <h2 style="color: var(--secondary);">❌ Access Denied</h2>
        <p>Only administrators can manage users.</p>
    </div>';
    exit;
}

$db = (new Database())->pdo;
$message = '';
$messageType = '';

// Handle User Creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_user') {
    if (!Security::checkCsrf($_POST['csrf_token'] ?? '')) {
        $message = 'Security token invalid';
        $messageType = 'error';
    } else {
        $email = Security::safe($_POST['email']);
        $password = $_POST['password'] ?? '';
        $name = Security::safe($_POST['name']);
        $role = $_POST['role'] ?? 'user';
        
        if (empty($email) || empty($password) || empty($name)) {
            $message = 'All fields are required';
            $messageType = 'error';
        } elseif (strlen($password) < 6) {
            $message = 'Password must be at least 6 characters';
            $messageType = 'error';
        } else {
            try {
                $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $db->prepare("INSERT INTO users (email, password, name, role, profile_completed) VALUES (?, ?, ?, ?, 1)");
                $stmt->execute([$email, $hashedPassword, $name, $role]);
                
                $message = 'User created successfully! They will need to change their password on first login.';
                $messageType = 'success';
            } catch (Exception $e) {
                if (strpos($e->getMessage(), 'UNIQUE constraint failed') !== false) {
                    $message = 'This email is already registered';
                } else {
                    $message = 'Error creating user: ' . $e->getMessage();
                }
                $messageType = 'error';
            }
        }
    }
}

// Handle Password Reset (Admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset_password') {
    if (!Security::checkCsrf($_POST['csrf_token'] ?? '')) {
        $message = 'Security token invalid';
        $messageType = 'error';
    } else {
        $userId = (int)$_POST['user_id'];
        $newPassword = $_POST['new_password'] ?? '';
        
        if (empty($newPassword) || strlen($newPassword) < 6) {
            $message = 'Password must be at least 6 characters';
            $messageType = 'error';
        } else {
            try {
                $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
                $stmt = $db->prepare("UPDATE users SET password=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                $stmt->execute([$hashedPassword, $userId]);
                
                $message = 'Password reset successfully!';
                $messageType = 'success';
            } catch (Exception $e) {
                $message = 'Error resetting password: ' . $e->getMessage();
                $messageType = 'error';
            }
        }
    }
}

// Fetch all users
$stmt = $db->prepare("SELECT id, email, name, role, profile_completed, created_at FROM users ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->fetchAll();
?>

<div class="dashboard-layout">
    <main class="dashboard-content">
        <!-- Header -->
        <div style="margin-bottom: 2rem;">
            <h1 style="color: var(--text-light); margin: 0;">👥 User Management</h1>
            <p style="opacity: 0.7; color: var(--text-light);">Create and manage user accounts</p>
        </div>

        <!-- Messages -->
        <?php if ($message): ?>
            <div style="
                background: <?php echo $messageType === 'success' ? 'rgba(76, 175, 80, 0.2)' : 'rgba(255, 77, 77, 0.2)'; ?>;
                border: 1px solid <?php echo $messageType === 'success' ? '#4CAF50' : '#ff4d4d'; ?>;
                color: <?php echo $messageType === 'success' ? '#90EE90' : '#ff9999'; ?>;
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 1.5rem;
                font-size: 0.95rem;
            ">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <!-- Create User Section -->
        <div class="glass-panel" style="margin-bottom: 2rem;">
            <h3 style="color: var(--primary); margin-top: 0;">➕ Create New User</h3>
            
            <form method="POST" style="display: grid; gap: 1rem;">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(Security::csrfToken()); ?>">
                <input type="hidden" name="action" value="create_user">

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Full Name *</label>
                        <input type="text" name="name" required placeholder="User's full name"
                               style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Email *</label>
                        <input type="email" name="email" required placeholder="user@example.com"
                               style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Password *</label>
                        <input type="password" name="password" required placeholder="Temporary password"
                               style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">Role *</label>
                        <select name="role" required
                                style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
                            <option value="user" style="background: #111; color: white;">User</option>
                            <option value="student" style="background: #111; color: white;">Student</option>
                            <option value="teacher" style="background: #111; color: white;">Teacher</option>
                            <option value="admin" style="background: #111; color: white;">Admin</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn-primary" style="width: 100%; padding: 12px; font-size: 1rem;">
                    ➕ Create User
                </button>
            </form>
        </div>

        <!-- Users List Section -->
        <div class="glass-panel">
            <h3 style="color: var(--primary); margin-top: 0;">📋 All Users (<?php echo count($users); ?>)</h3>

            <?php if (count($users) > 0): ?>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 2px solid rgba(255,255,255,0.1);">
                                <th style="text-align: left; padding: 12px; color: var(--primary);">Name</th>
                                <th style="text-align: left; padding: 12px; color: var(--primary);">Email</th>
                                <th style="text-align: left; padding: 12px; color: var(--primary);">Role</th>
                                <th style="text-align: left; padding: 12px; color: var(--primary);">Profile</th>
                                <th style="text-align: left; padding: 12px; color: var(--primary);">Joined</th>
                                <th style="text-align: left; padding: 12px; color: var(--primary);">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                                <tr style="border-bottom: 1px solid rgba(255,255,255,0.05);">
                                    <td style="padding: 12px; color: var(--text-light);">
                                        <?php echo htmlspecialchars($u['name'] ?? 'N/A'); ?>
                                    </td>
                                    <td style="padding: 12px; color: var(--text-light);">
                                        <?php echo htmlspecialchars($u['email']); ?>
                                    </td>
                                    <td style="padding: 12px;">
                                        <span style="
                                            background: <?php echo $u['role'] === 'admin' ? '#E91E63' : ($u['role'] === 'teacher' ? '#2196F3' : '#4CAF50'); ?>;
                                            color: white;
                                            padding: 4px 12px;
                                            border-radius: 20px;
                                            font-size: 0.8rem;
                                            font-weight: 500;
                                        ">
                                            <?php echo htmlspecialchars(ucfirst($u['role'])); ?>
                                        </span>
                                    </td>
                                    <td style="padding: 12px; color: var(--text-light);">
                                        <?php echo $u['profile_completed'] ? '✓ Complete' : '⚠️ Incomplete'; ?>
                                    </td>
                                    <td style="padding: 12px; color: var(--text-light); font-size: 0.9rem;">
                                        <?php echo date('M d, Y', strtotime($u['created_at'])); ?>
                                    </td>
                                    <td style="padding: 12px;">
                                        <!-- Reset Password Button -->
                                        <button onclick="openResetModal(<?php echo $u['id']; ?>, '<?php echo htmlspecialchars($u['name']); ?>')" 
                                                style="
                                                    background: transparent;
                                                    border: 1px solid #2196F3;
                                                    color: #2196F3;
                                                    padding: 6px 12px;
                                                    border-radius: 6px;
                                                    cursor: pointer;
                                                    font-size: 0.85rem;
                                                    transition: all 0.2s;
                                                "
                                                onmouseover="this.style.background='#2196F3'; this.style.color='white';"
                                                onmouseout="this.style.background='transparent'; this.style.color='#2196F3';">
                                            🔑 Reset
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p style="text-align: center; color: var(--text-light); opacity: 0.7;">No users found</p>
            <?php endif; ?>
        </div>

    </main>
</div>

<!-- Reset Password Modal -->
<div id="resetModal" style="
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
    z-index: 1000;
    justify-content: center;
    align-items: center;
">
    <div class="glass-panel" style="
        width: 90%;
        max-width: 400px;
        animation: slideUp 0.3s ease;
    ">
        <h3 style="color: var(--primary); margin-top: 0;">🔑 Reset Password</h3>
        <p style="color: var(--text-light); opacity: 0.8;">Reset password for: <strong id="resetUserName"></strong></p>

        <form method="POST" style="display: grid; gap: 1rem;">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(Security::csrfToken()); ?>">
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="user_id" id="resetUserId" value="">

            <div>
                <label style="display: block; margin-bottom: 0.5rem; font-weight: 500;">New Password *</label>
                <input type="password" name="new_password" required placeholder="Enter new password"
                       style="width: 100%; padding: 10px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: var(--text-light); outline: none;">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <button type="button" onclick="closeResetModal()" 
                        style="
                            background: transparent;
                            border: 1px solid rgba(255,255,255,0.2);
                            color: var(--text-light);
                            padding: 10px;
                            border-radius: 8px;
                            cursor: pointer;
                            transition: all 0.2s;
                        "
                        onmouseover="this.style.background='rgba(255,255,255,0.1)'"
                        onmouseout="this.style.background='transparent'">
                    Cancel
                </button>
                <button type="submit" class="btn-primary" style="padding: 10px;">
                    🔄 Reset Password
                </button>
            </div>
        </form>
    </div>
</div>

<style>
    @keyframes slideUp {
        from {
            transform: translateY(20px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
</style>

<script>
    function openResetModal(userId, userName) {
        document.getElementById('resetUserId').value = userId;
        document.getElementById('resetUserName').textContent = userName;
        document.getElementById('resetModal').style.display = 'flex';
    }

    function closeResetModal() {
        document.getElementById('resetModal').style.display = 'none';
    }

    // Close modal when clicking outside
    document.getElementById('resetModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeResetModal();
        }
    });
</script>
