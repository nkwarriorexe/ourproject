<div class="container" style="display: flex; justify-content: center; align-items: center; min-height: 80vh;">
    
    <!-- Login Card -->
    <div class="glass-panel" style="width: 100%; max-width: 400px; animation: fadeInUp 0.8s ease;">
        
        <div style="text-align: center; margin-bottom: 2rem;">
            <h2 style="color: var(--primary); margin: 0;">Welcome Back</h2>
            <p style="opacity: 0.7; font-size: 0.9rem;">Secure Portal Access</p>
        </div>

        <!-- Flash Message for Errors -->
        <?php if(isset($_GET['error'])): ?>
            <div style="background: rgba(255, 77, 77, 0.2); border: 1px solid #ff4d4d; color: #ff9999; padding: 10px; border-radius: 8px; margin-bottom: 20px; font-size: 0.9rem; text-align: center;">
                <?= htmlspecialchars($_GET['error'] === 'invalid' ? 'Invalid Credentials' : 'Access Denied') ?>
            </div>
        <?php endif; ?>

        <form action="index.php?action=login_submit" method="POST">
            <!-- CSRF Protection -->
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(Security::csrfToken()) ?>">

            <div style="margin-bottom: 1.5rem;">
                <label style="display: block; margin-bottom: 8px; font-size: 0.9rem;">Email</label>
                <input type="email" name="email" required placeholder="your@email.com" 
                       style="width: 100%; padding: 12px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: white; outline: none;">
            </div>

            <div style="margin-bottom: 2rem;">
                <label style="display: block; margin-bottom: 8px; font-size: 0.9rem;">Password</label>
                <input type="password" name="password" required placeholder="••••••••" 
                       style="width: 100%; padding: 12px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; color: white; outline: none;">
            </div>

            <button type="submit" class="btn-primary" style="width: 100%; padding: 14px; font-size: 1rem;">
                Secure Login →
            </button>
        </form>

        <div style="text-align: center; margin-top: 1.5rem;">
            <a href="#" style="color: var(--text-light); opacity: 0.5; font-size: 0.8rem; text-decoration: none;">Forgot Password?</a>
        </div>
    </div>

</div>