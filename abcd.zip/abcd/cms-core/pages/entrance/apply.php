<?php
$db = (new Database())->pdo;
$uid = $_SESSION['user_id'];

// Check if user already has an application
$check = $db->prepare("SELECT * FROM applications WHERE user_id = ?");
$check->execute([$uid]);
$existing = $check->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && (!$existing || $existing['status'] == 'rejected')) {
    if ($existing && $existing['resubmit_count'] >= 2) {
        $error = "Maximum resubmission limit (2) reached.";
    } else {
        $app_id = "ADM-" . date('Y') . "-" . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
        $resubmit_inc = $existing ? $existing['resubmit_count'] + 1 : 0;
        
        $sql = "REPLACE INTO applications (app_id, user_id, full_name, father_name, see_symbol_no, see_gpa, phone, course, status, resubmit_count) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)";
        $stmt = $db->prepare($sql);
        $stmt->execute([$app_id, $uid, $_POST['name'], $_POST['father'], $_POST['symbol'], $_POST['gpa'], $_POST['phone'], $_POST['course'], $resubmit_inc]);
        header("Location: index.php?page=entrance_dashboard");
    }
}
?>
<div class="glass-panel" style="max-width: 600px; margin: 20px auto;">
    <h2>🇳🇵 Entrance Registration</h2>
    <form method="POST">
        <label>Full Name (As per SEE)</label><input type="text" name="name" required style="width:100%; padding:10px;">
        <label>Father's Name</label><input type="text" name="father" required style="width:100%; padding:10px;">
        <div style="display:flex; gap:10px;">
            <div style="flex:1;"><label>SEE Symbol No</label><input type="text" name="symbol" required style="width:100%; padding:10px;"></div>
            <div style="flex:1;"><label>SEE GPA</label><input type="number" step="0.01" name="gpa" required style="width:100%; padding:10px;"></div>
        </div>
        <label>Mobile Number</label><input type="text" name="phone" required style="width:100%; padding:10px;">
        <label>Apply for Course</label>
        <select name="course" style="width:100%; padding:10px;">
            <option>Science (Bachelors)</option>
            <option>BCA / BIT</option>
            <option>Management</option>
        </select>
        <button type="submit" class="btn btn-primary" style="width:100%; margin-top:20px;">Submit Admission Form</button>
    </form>
</div>
