<?php
$db = (new Database())->pdo;
$stmt = $db->prepare("SELECT * FROM applications WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$app = $stmt->fetch();
?>
<div class="dashboard-layout">
    <?php include 'includes/sidebar.php'; ?>
    <main style="padding:40px; flex:1;">
        <div class="glass-panel">
            <h1>Applicant Portal</h1>
            <?php if(!$app): ?>
                <p>No active application. <a href="index.php?page=apply">Apply Now</a></p>
            <?php else: ?>
                <div style="border:1px solid #ddd; padding:20px; border-radius:10px;">
                    <h3>Application ID: <span style="color:var(--primary)"><?= $app['app_id'] ?></span></h3>
                    <p>Status: <strong><?= strtoupper($app['status']) ?></strong></p>
                    <p>Payment: <strong><?= strtoupper($app['payment_status']) ?></strong></p>
                    
                    <hr>
                    <?php if($app['status'] == 'approved' && $app['payment_status'] == 'paid'): ?>
                        <div style="display:flex; gap:10px; margin-top:20px;">
                            <a href="generate_admit.php" class="btn btn-gold">🎫 Download Admit Card</a>
                            <a href="index.php?page=entrance_exam" class="btn btn-primary">✍️ Start Online Exam</a>
                        </div>
                    <?php elseif($app['payment_status'] == 'unpaid'): ?>
                        <p style="color:red; font-weight:bold;">⚠️ Visit College Finance to pay your entrance fee to unlock Admit Card & Exam.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</div>
