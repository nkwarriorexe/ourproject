<?php
$db = (new Database())->pdo;

// Handle Actions
if (isset($_GET['action'])) {
    if ($_GET['action'] == 'mark_paid') {
        $db->prepare("UPDATE applications SET payment_status='paid' WHERE id=?")->execute([$_GET['id']]);
    }
    if ($_GET['action'] == 'approve') {
        $db->prepare("UPDATE applications SET status='approved' WHERE id=?")->execute([$_GET['id']]);
    }
}

$pending = $db->query("SELECT * FROM applications ORDER BY applied_at DESC")->fetchAll();
?>
<div class="dashboard-layout">
    <?php include 'includes/sidebar.php'; ?>
    <main style="padding:40px; flex:1;">
        <div class="glass-panel">
            <h2>Applicant Management</h2>
            <table style="width:100%; margin-top:20px; border-collapse:collapse;">
                <tr style="background:var(--primary); color:white;">
                    <th style="padding:10px;">Applicant ID</th>
                    <th>Name</th>
                    <th>Payment</th>
                    <th>Form Status</th>
                    <th>Actions</th>
                </tr>
                <?php foreach($pending as $p): ?>
                <tr style="border-bottom:1px solid #eee;">
                    <td style="padding:10px;"><?= $p['app_id'] ?></td>
                    <td><?= $p['full_name'] ?></td>
                    <td><?= $p['payment_status'] ?></td>
                    <td><?= $p['status'] ?></td>
                    <td>
                        <a href="?page=admin_control&action=mark_paid&id=<?= $p['id'] ?>">💰 Pay</a>
                        <a href="?page=admin_control&action=approve&id=<?= $p['id'] ?>">✅ Approve</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </main>
</div>
