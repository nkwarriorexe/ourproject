<?php
if (!Auth::isLoggedIn()) { header('Location: login.php'); exit; }
require_once 'includes/sidebar.php';
?>
<div class="dashboard-layout">
    <main style="padding: 40px; background: #F1F5F9; flex: 1;">
        <header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <h1>Institutional Overview</h1>
            <div style="background: white; padding: 10px 20px; border-radius: 30px; border: 1px solid var(--primary); color: var(--primary); font-weight: bold;">
                Role: <?= strtoupper($_SESSION['role']) ?>
            </div>
        </header>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 40px;">
            <div style="background: var(--primary); color: white; padding: 30px; border-radius: 15px;">
                <p>Total Students</p>
                <h2 style="font-size: 2.5rem;">4,829</h2>
            </div>
            <div style="background: var(--secondary); color: var(--primary); padding: 30px; border-radius: 15px;">
                <p>Pending Applications</p>
                <h2 style="font-size: 2.5rem;">124</h2>
            </div>
            <div style="background: white; color: var(--primary); padding: 30px; border-radius: 15px; border: 1px solid #ddd;">
                <p>System Uptime</p>
                <h2 style="font-size: 2.5rem;">99.9%</h2>
            </div>
        </div>

        <div class="glass-panel">
            <h3>Recent System Activity</h3>
            <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                <tr style="text-align: left; border-bottom: 2px solid #eee;">
                    <th style="padding: 10px;">User</th>
                    <th>Action</th>
                    <th>Timestamp</th>
                </tr>
                <tr>
                    <td style="padding: 10px;">Admin_01</td>
                    <td>Updated Exam Schedule</td>
                    <td>10 mins ago</td>
                </tr>
                <tr>
                    <td style="padding: 10px;">System</td>
                    <td>Backup Completed</td>
                    <td>2 hours ago</td>
                </tr>
            </table>
        </div>
    </main>
</div>
