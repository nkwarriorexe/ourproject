<?php
$db = (new Database())->pdo;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $marks = $_POST['marks'];
    $grade = 'F';
    if ($marks >= 90) $grade = 'A+';
    elseif ($marks >= 80) $grade = 'A';
    elseif ($marks >= 70) $grade = 'B';
    
    $stmt = $db->prepare("INSERT INTO results (student_id, subject, marks, grade) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_POST['student_id'], $_POST['subject'], $marks, $grade]);
    $success = "Grade Published!";
}
$students = $db->query("SELECT * FROM users WHERE role='student'")->fetchAll();
?>
<div class="dashboard-layout">
    <?php include 'includes/sidebar.php'; ?>
    <main style="padding: 40px; flex:1;">
        <div class="glass-panel" style="max-width:500px;">
            <h2>Enter Student Grade</h2>
            <?php if(isset($success)) echo "<p style='color:green'>$success</p>"; ?>
            <form method="POST">
                <label>Select Student</label>
                <select name="student_id" style="width:100%; padding:10px; margin:10px 0;">
                    <?php foreach($students as $s): ?>
                        <option value="<?= $s['id'] ?>"><?= $s['name'] ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" name="subject" placeholder="Subject Name" required style="width:100%; padding:10px; margin:10px 0;">
                <input type="number" name="marks" placeholder="Marks (0-100)" required style="width:100%; padding:10px; margin:10px 0;">
                <button type="submit" class="btn btn-primary" style="width:100%;">Publish Result</button>
            </form>
        </div>
    </main>
</div>
