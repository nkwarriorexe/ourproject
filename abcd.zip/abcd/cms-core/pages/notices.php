<?php
// Ensure user is logged in
if (!Auth::isLoggedIn()) {
    header("Location: index.php?page=login");
    exit;
}

require_once 'includes/sidebar.php';

error_log("=== NOTICES PAGE LOAD START ===");

try {
    $notices = new Notices();
    $noticeId = $_GET['notice_id'] ?? null;
    $searchQuery = $_GET['search'] ?? '';
    $filterCategory = $_GET['category'] ?? 'all';

    error_log("Fetching notices for user: " . $_SESSION['user_id'] . ", role: " . ($_SESSION['role'] ?? 'unknown'));

    // Get single notice if viewing details
    $singleNotice = null;
    if ($noticeId) {
        error_log("Fetching single notice ID: " . $noticeId);
        $singleNotice = $notices->getNoticeById($noticeId);
        if ($singleNotice) {
            $notices->markAsRead($_SESSION['user_id'], $noticeId);
        }
    }

    // Get all notices for user
    error_log("Getting all notices for user...");
    $allNotices = $notices->getNoticesForUser($_SESSION['user_id'], $_SESSION['role'] ?? 'user', 100);
    error_log("Notices retrieved: " . count($allNotices) . " total");

    // Filter by category if needed
    if ($filterCategory !== 'all') {
        $allNotices = array_filter($allNotices, function($n) use ($filterCategory) {
            return $n['category'] === $filterCategory;
        });
    }

    // Filter by search query if needed
    if ($searchQuery) {
        $searchQuery = strtolower($searchQuery);
        $allNotices = array_filter($allNotices, function($n) use ($searchQuery) {
            return stripos($n['title'], $searchQuery) !== false || 
                   stripos($n['content'], $searchQuery) !== false;
        });
    }

    error_log("Final notices count after filters: " . count($allNotices));
    $unreadCount = $notices->getUnreadCount($_SESSION['user_id']);
    error_log("=== NOTICES PAGE LOAD COMPLETE ===");
} catch (Exception $e) {
    error_log("ERROR IN NOTICES PAGE: " . $e->getMessage());
    error_log($e->getTraceAsString());
    $allNotices = [];
    $singleNotice = null;
    $unreadCount = 0;
}
?>

<div class="dashboard-layout">
    <main class="dashboard-content">
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
            <div>
                <h1 style="margin: 0; font-size: 2rem; color: var(--text-light);">📢 Notices</h1>
                <p style="opacity: 0.7; color: var(--text-light); margin-top: 5px;">
                    Stay updated with important announcements
                    <?php if ($unreadCount > 0): ?>
                        <span style="background: #ff6b6b; color: white; padding: 2px 8px; border-radius: 20px; font-size: 0.8rem; margin-left: 10px;">
                            <?= $unreadCount ?> unread
                        </span>
                    <?php endif; ?>
                </p>
            </div>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="index.php?page=admin_notices" style="
                    background: var(--primary);
                    color: white;
                    padding: 10px 20px;
                    border-radius: 8px;
                    text-decoration: none;
                    font-weight: 500;
                    transition: all 0.2s;
                " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    ⚙️ Manage Notices
                </a>
            <?php endif; ?>
        </div>

        <!-- Search and Filter -->
        <div style="display: grid; grid-template-columns: 1fr 200px; gap: 15px; margin-bottom: 25px;">
            <form method="GET" style="display: flex; gap: 10px;">
                <input type="hidden" name="page" value="notices">
                <input 
                    type="text" 
                    name="search" 
                    placeholder="Search notices..." 
                    value="<?= htmlspecialchars($searchQuery) ?>"
                    style="
                        flex: 1;
                        padding: 10px 15px;
                        background: rgba(255,255,255,0.1);
                        border: 1px solid rgba(255,255,255,0.2);
                        border-radius: 8px;
                        color: var(--text-light);
                        font-family: inherit;
                    "
                >
                <button type="submit" style="
                    padding: 10px 20px;
                    background: var(--primary);
                    color: white;
                    border: none;
                    border-radius: 8px;
                    cursor: pointer;
                    font-weight: 500;
                    transition: all 0.2s;
                " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    Search
                </button>
            </form>

            <form method="GET" style="display: flex;">
                <input type="hidden" name="page" value="notices">
                <select name="category" onchange="this.form.submit()" style="
                    width: 100%;
                    padding: 10px 15px;
                    background: rgba(255,255,255,0.1);
                    border: 1px solid rgba(255,255,255,0.2);
                    border-radius: 8px;
                    color: var(--text-light);
                    cursor: pointer;
                    font-family: inherit;
                ">
                    <option value="all">All Categories</option>
                    <option value="urgent" <?= $filterCategory === 'urgent' ? 'selected' : '' ?>>🔴 Urgent</option>
                    <option value="academic" <?= $filterCategory === 'academic' ? 'selected' : '' ?>>📚 Academic</option>
                    <option value="admin" <?= $filterCategory === 'admin' ? 'selected' : '' ?>>⚙️ Admin</option>
                    <option value="event" <?= $filterCategory === 'event' ? 'selected' : '' ?>>🎉 Events</option>
                    <option value="general" <?= $filterCategory === 'general' ? 'selected' : '' ?>>📢 General</option>
                </select>
            </form>
        </div>

        <?php if ($singleNotice): ?>
            <!-- Single Notice View -->
            <div style="margin-bottom: 30px;">
                <a href="index.php?page=notices" style="
                    color: var(--primary);
                    text-decoration: none;
                    font-weight: 500;
                    margin-bottom: 15px;
                    display: inline-block;
                ">← Back to Notices</a>

                <div style="
                    background: var(--glass);
                    backdrop-filter: blur(15px);
                    border: 1px solid rgba(255,255,255,0.1);
                    border-radius: 12px;
                    padding: 30px;
                    color: var(--text-light);
                ">
                    <!-- Title and Meta -->
                    <div style="margin-bottom: 20px;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <span style="
                                padding: 5px 12px;
                                background: var(--primary);
                                border-radius: 20px;
                                font-size: 0.8rem;
                                text-transform: uppercase;
                                font-weight: 600;
                            ">
                                <?php
                                $categoryEmoji = [
                                    'urgent' => '🔴',
                                    'academic' => '📚',
                                    'admin' => '⚙️',
                                    'event' => '🎉',
                                    'general' => '📢'
                                ];
                                echo ($categoryEmoji[$singleNotice['category']] ?? '📌') . ' ' . ucfirst($singleNotice['category']);
                                ?>
                            </span>
                            <span style="
                                padding: 5px 12px;
                                background: <?php
                                $priorityColor = [
                                    'critical' => '#ff4444',
                                    'high' => '#ff9800',
                                    'medium' => '#2196F3',
                                    'low' => '#4CAF50'
                                ];
                                echo $priorityColor[$singleNotice['priority']] ?? '#2196F3';
                                ?>;
                                border-radius: 20px;
                                font-size: 0.8rem;
                                text-transform: uppercase;
                                font-weight: 600;
                            ">
                                Priority: <?= ucfirst($singleNotice['priority']) ?>
                            </span>
                        </div>

                        <h2 style="font-size: 2rem; margin: 0 0 15px 0;">
                            <?= htmlspecialchars($singleNotice['title']) ?>
                        </h2>

                        <div style="display: flex; gap: 30px; opacity: 0.7; font-size: 0.9rem;">
                            <span>📅 <?= date('M d, Y - H:i', strtotime($singleNotice['created_at'])) ?></span>
                            <span>👤 <?= htmlspecialchars($singleNotice['creator']['full_name'] ?? 'Unknown') ?></span>
                            <?php if ($singleNotice['expires_at']): ?>
                                <span>⏰ Expires: <?= date('M d, Y', strtotime($singleNotice['expires_at'])) ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <hr style="border: none; border-top: 1px solid rgba(255,255,255,0.1); margin: 20px 0;">

                    <!-- Content -->
                    <div style="
                        line-height: 1.8;
                        font-size: 1rem;
                        margin-bottom: 20px;
                    ">
                        <?= nl2br(htmlspecialchars($singleNotice['content'])) ?>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <!-- Notices List View -->
            <?php if (empty($allNotices)): ?>
                <div style="
                    background: var(--glass);
                    backdrop-filter: blur(15px);
                    border: 1px solid rgba(255,255,255,0.1);
                    border-radius: 12px;
                    padding: 40px;
                    text-align: center;
                    color: var(--text-light);
                ">
                    <div style="font-size: 3rem; margin-bottom: 15px;">📭</div>
                    <h3 style="margin: 0 0 10px 0;">No Notices Available</h3>
                    <p style="opacity: 0.7;">Check back later for important announcements.</p>
                </div>
            <?php else: ?>
                <div style="display: grid; gap: 15px;">
                    <?php foreach ($allNotices as $notice): ?>
                        <?php
                        // Check if user has read this notice
                        $hasRead = false;
                        // We'll mark as read when viewing details
                        ?>
                        <a 
                            href="index.php?page=notices&notice_id=<?= $notice['id'] ?>"
                            style="
                                text-decoration: none;
                                color: inherit;
                                display: block;
                                background: var(--glass);
                                backdrop-filter: blur(15px);
                                border: 1px solid rgba(255,255,255,0.1);
                                border-radius: 12px;
                                padding: 20px;
                                transition: all 0.3s;
                                border-left: 5px solid <?php
                                    $priorityColor = [
                                        'critical' => '#ff4444',
                                        'high' => '#ff9800',
                                        'medium' => '#2196F3',
                                        'low' => '#4CAF50'
                                    ];
                                    echo $priorityColor[$notice['priority']] ?? '#2196F3';
                                ?>;
                            "
                            onmouseover="this.style.transform='translateX(5px)'; this.style.borderColor='rgba(255,255,255,0.3)'"
                            onmouseout="this.style.transform='translateX(0)'; this.style.borderColor='rgba(255,255,255,0.1)'"
                        >
                            <div style="display: flex; justify-content: space-between; align-items: start;">
                                <div style="flex: 1;">
                                    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                                        <span style="font-size: 1.2rem;">
                                            <?php
                                            $categoryEmoji = [
                                                'urgent' => '🔴',
                                                'academic' => '📚',
                                                'admin' => '⚙️',
                                                'event' => '🎉',
                                                'general' => '📢'
                                            ];
                                            echo $categoryEmoji[$notice['category']] ?? '📌';
                                            ?>
                                        </span>
                                        <h3 style="margin: 0; color: var(--text-light); font-size: 1.1rem;">
                                            <?= htmlspecialchars(substr($notice['title'], 0, 60)) ?>
                                            <?= strlen($notice['title']) > 60 ? '...' : '' ?>
                                        </h3>
                                    </div>

                                    <p style="
                                        margin: 8px 0;
                                        opacity: 0.8;
                                        color: var(--text-light);
                                        font-size: 0.9rem;
                                    ">
                                        <?= htmlspecialchars(substr(strip_tags($notice['content']), 0, 100)) ?>...
                                    </p>

                                    <div style="display: flex; gap: 15px; margin-top: 10px; font-size: 0.85rem; opacity: 0.6;">
                                        <span>📅 <?= date('M d, Y', strtotime($notice['created_at'])) ?></span>
                                        <span>⏱️ <?= date('H:i', strtotime($notice['created_at'])) ?></span>
                                    </div>
                                </div>

                                <div style="text-align: right; margin-left: 20px;">
                                    <span style="
                                        display: inline-block;
                                        padding: 5px 12px;
                                        background: <?php
                                            $priorityColor = [
                                                'critical' => '#ff4444',
                                                'high' => '#ff9800',
                                                'medium' => '#2196F3',
                                                'low' => '#4CAF50'
                                            ];
                                            echo $priorityColor[$notice['priority']] ?? '#2196F3';
                                        ?>;
                                        border-radius: 20px;
                                        font-size: 0.75rem;
                                        text-transform: uppercase;
                                        font-weight: 600;
                                        color: white;
                                    ">
                                        <?= ucfirst($notice['priority']) ?>
                                    </span>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </main>
</div>
