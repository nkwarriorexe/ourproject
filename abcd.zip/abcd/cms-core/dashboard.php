<?php
require_once 'config/db.php';
require_once 'core/Auth.php';
session_start();
if (!Auth::isLoggedIn()) { header('Location: login.php'); exit; }
include 'includes/header.php';
?>
<div style="display: flex; min-height: 100vh;">
    <!-- Sidebar -->
    <aside style="width: 250px; background: var(--bg-card); border-right: 1px solid var(--border); padding: 20px;">
        <h3 style="color: var(--primary); margin-bottom: 30px;">Dashboard</h3>
        <ul style="list-style: none;">
            <li style="margin-bottom: 15px;"><a href="dashboard.php" style="color: var(--primary); text-decoration: none; font-weight: bold;">🏠 Overview</a></li>
            <li style="margin-bottom: 15px;"><a href="manage_notices.php" style="color: var(--text-main); text-decoration: none;">📢 Manage Notices</a></li>
            <li style="margin-bottom: 15px;"><a href="settings.php" style="color: var(--text-main); text-decoration: none;">⚙️ Site Settings</a></li>
            <li style="margin-bottom: 15px;"><a href="logout.php" style="color: #ef4444; text-decoration: none;">🔒 Logout</a></li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main style="flex: 1; padding: 40px; background: var(--bg-main);">
        <header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 40px;">
            <h1>Welcome back, <?php echo $_SESSION['name']; ?>!</h1>
            <div style="padding: 10px 20px; background: var(--bg-card); border-radius: 12px; border: 1px solid var(--border);">
                Admin Status: <span style="color: green;">Online</span>
            </div>
        </header>

        <!-- Stats Cards -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 40px;">
            <div style="background: var(--bg-card); padding: 25px; border-radius: 20px; border: 1px solid var(--border);">
                <p style="color: var(--text-muted);">Total Students</p>
                <h2 style="font-size: 2rem;">1,284</h2>
            </div>
            <div style="background: var(--bg-card); padding: 25px; border-radius: 20px; border: 1px solid var(--border);">
                <p style="color: var(--text-muted);">Pending Applications</p>
                <h2 style="font-size: 2rem; color: var(--primary);">42</h2>
            </div>
        </div>

        <!-- Realtime Analysis Chart -->
        <div style="background: var(--bg-card); padding: 30px; border-radius: 20px; border: 1px solid var(--border);">
            <h3>Traffic Analysis</h3>
            <canvas id="analyticsChart" style="width: 100%; height: 300px;"></canvas>
        </div>
    </main>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const ctx = document.getElementById('analyticsChart').getContext('2d');
new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
            label: 'Site Visitors',
            data: [400, 600, 800, 500, 900, 1100, 1500],
            borderColor: '#f97316',
            backgroundColor: 'rgba(249, 115, 22, 0.1)',
            fill: true,
            tension: 0.4
        }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});
</script>
